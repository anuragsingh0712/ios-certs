import { useState, useEffect } from 'react';
import 'react-native-gesture-handler';
import React, { createContext, useCallback, useMemo, useState } from 'react';
import { Platform, StyleSheet } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { enableScreens } from 'react-native-screens';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { useFonts } from 'expo-font';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
} from '@expo-google-fonts/inter';
import { RootNavigator } from './src/navigation';
import { mockContactSubmissions, mockNotifications, mockPlans, mockUser } from './src/data/mockData';
import { ContactSubmission, NotificationItem, User } from './src/types';

enableScreens(Platform.OS !== 'web');

interface AppContextState {
  session: boolean;
  setSession: (value: boolean) => void;
  user: User;
  setUser: (user: User) => void;
  updateUser: (updates: Partial<User>) => void;
  selectedPlanId: string;
  setSelectedPlanId: (id: string) => void;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  notificationsEnabled: boolean;
  toggleNotifications: () => void;
  bookmarks: string[];
  toggleBookmark: (id: string) => void;
  notifications: NotificationItem[];
  markAllRead: () => void;
  toggleNotificationRead: (id: string) => void;
  dismissNotification: (id: string) => void;
  contactSubmissions: ContactSubmission[];
  addContactSubmission: (submission: ContactSubmission) => void;
  clearLocalData: () => void;
}

export const AppContext = createContext<AppContextState | null>(null);

export const useAppContext = () => {
  const context = React.useContext(AppContext);
  if (!context) {
    throw new Error('AppContext not available');
  }
  return context;
};

export default function App() {
  const [fontsLoaded] = useFonts({
    'Inter-Regular': Inter_400Regular,
    'Inter-Medium': Inter_500Medium,
    'Inter-SemiBold': Inter_600SemiBold,
    'Inter-Bold': Inter_700Bold,
  });

  const [session, setSession] = useState(false);
  const [user, setUser] = useState<User>(mockUser);
  const [selectedPlanId, setSelectedPlanId] = useState<string>(mockPlans[1].id);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [bookmarks, setBookmarks] = useState<string[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>(mockNotifications);
  const [contactSubmissions, setContactSubmissions] = useState<ContactSubmission[]>(mockContactSubmissions);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  const toggleNotifications = useCallback(() => {
    setNotificationsEnabled((prev) => !prev);
  }, []);

  const toggleBookmark = useCallback((id: string) => {
    setBookmarks((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]));
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications((prev) => prev.map((item) => ({ ...item, read: true })));
  }, []);

  const toggleNotificationRead = useCallback((id: string) => {
    setNotifications((prev) => prev.map((item) => (item.id === id ? { ...item, read: !item.read } : item)));
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const addContactSubmission = useCallback((submission: ContactSubmission) => {
    setContactSubmissions((prev) => [submission, ...prev]);
  }, []);

  const updateUser = useCallback((updates: Partial<User>) => {
    setUser((prev) => ({ ...prev, ...updates }));
  }, []);

  const clearLocalData = useCallback(() => {
    setBookmarks([]);
    setNotifications(mockNotifications);
    setContactSubmissions([]);
    setSelectedPlanId(mockPlans[0].id);
  }, []);

  const contextValue = useMemo(
    () => ({
      session,
      setSession,
      user,
      setUser,
      updateUser,
      selectedPlanId,
      setSelectedPlanId,
      theme,
      toggleTheme,
      notificationsEnabled,
      toggleNotifications,
      bookmarks,
      toggleBookmark,
      notifications,
      markAllRead,
      toggleNotificationRead,
      dismissNotification,
      contactSubmissions,
      addContactSubmission,
      clearLocalData,
    }),
    [
      session,
      user,
      selectedPlanId,
      theme,
      notificationsEnabled,
      bookmarks,
      notifications,
      contactSubmissions,
      toggleTheme,
      toggleNotifications,
      toggleBookmark,
      markAllRead,
      toggleNotificationRead,
      dismissNotification,
      addContactSubmission,
      updateUser,
      clearLocalData,
    ]
  );

  if (!fontsLoaded) return null;

  return (
    <GestureHandlerRootView style={styles.root}>
      <SafeAreaProvider style={styles.root}>
        <AppContext.Provider value={contextValue}>
          <NavigationContainer>
            <RootNavigator />
          </NavigationContainer>
        </AppContext.Provider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    ...(Platform.OS === 'web' ? { height: '100vh' as any, maxHeight: '100vh' as any, overflow: 'hidden' as any } : {}),
  },
});
