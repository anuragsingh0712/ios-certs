# test_business_logic_validation_iOS_ipa — Screens & Navigation

## How to run
cd /home/hewlett/projects/frontendX_backend_merged/frontend_runs/run_3d3258fd_20260701_173610/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Login | src/screens/LoginScreen.tsx | Email/password authentication with mock credentials and social placeholders. |
| ForgotPassword | src/screens/ForgotPasswordScreen.tsx | Password recovery workflow with validation states. |
| Home | src/screens/HomeScreen.tsx | KPI cards, quick actions, and recent activity feed. |
| Dashboard | src/screens/DashboardScreen.tsx | KPI performance metrics with daily/weekly/monthly filters. |
| Features | src/screens/FeaturesScreen.tsx | Feature suite list with adoption metrics. |
| FeatureDetail | src/screens/FeatureDetailScreen.tsx | Feature insights, benefits, workflows, and usage stats. |
| Pricing | src/screens/PricingScreen.tsx | Plan selection with monthly/yearly toggle and savings. |
| PlanConfirmation | src/screens/PlanConfirmationScreen.tsx | Confirmation of selected pricing plan. |
| Resources | src/screens/ResourcesScreen.tsx | Searchable resource library with filters and bookmarks. |
| ResourceDetail | src/screens/ResourceDetailScreen.tsx | Resource details with bookmark toggle. |
| Profile | src/screens/ProfileScreen.tsx | User profile, plan info, preferences, and actions. |
| EditProfile | src/screens/EditProfileScreen.tsx | Edit user name and company information. |
| Contact | src/screens/ContactScreen.tsx | Contact form with validation and simulated submission. |
| Notifications | src/screens/NotificationsScreen.tsx | Notification center with read/unread and dismiss actions. |
| Testimonials | src/screens/TestimonialsScreen.tsx | Swipeable testimonials with pagination controls. |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen for unknown routes. |

## Navigation map
- Login -> MainTabs (tap Sign In after valid credentials)
- Login -> ForgotPassword (tap Forgot password)
- MainTabs(Home) -> Pricing (tap Pricing quick action)
- MainTabs(Home) -> Notifications (tap Notifications quick action)
- MainTabs(Home) -> Contact (tap Contact quick action)
- MainTabs(Home) -> Testimonials (tap Testimonials quick action)
- Features -> FeatureDetail (tap feature card)
- Resources -> ResourceDetail (tap resource card)
- Pricing -> PlanConfirmation (tap Confirm selection)
- Profile -> EditProfile (tap Edit profile)
- Profile -> Pricing (tap Pricing)
- Profile -> Notifications (tap Notifications)
- Profile -> Contact (tap Contact support)
- Profile -> Testimonials (tap Testimonials)
- Profile -> Login (tap Log out)

## Shared components
- src/components/HeaderBar.tsx — Title/subtitle header with optional action.
- src/components/PrimaryButton.tsx — Gradient primary call-to-action button.
- src/components/SectionHeader.tsx — Section titles with optional action button.
- src/components/KpiCard.tsx — KPI summary card.
- src/components/ActivityRow.tsx — Activity list row.
- src/components/PlanCard.tsx — Pricing plan selection card.
- src/components/ResourceCard.tsx — Resource summary card.
- src/components/EmptyState.tsx — Empty/error state block.
- src/components/SegmentedControl.tsx — Segmented filter control.
- src/components/NotificationRow.tsx — Notification list row with dismiss action.
- src/components/TextField.tsx — Labeled text input.
- src/components/FeatureCard.tsx — Feature preview card with usage bar.

## Design tokens
primary, primaryDark, primaryLight, accent, background, surface, card, border, textPrimary, textSecondary, textDisabled, textInverse, success, warning, error, info, shadowColor.
