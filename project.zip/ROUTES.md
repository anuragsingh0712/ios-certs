# modify test git — Screens & Navigation

## How to run
cd /home/hewlett/projects/frontend_generator_backend/frontend_generator_backend/frontend_runs/run_2effd175_20260618_113127/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Home | src/screens/HomeScreen.tsx | Subject recommendations with hero illustration and upcoming lessons list. |
| Schedule | src/screens/ScheduleScreen.tsx | Weekly schedule with day chips and time-based lesson cards. |
| Messages | src/screens/MessagesScreen.tsx | Placeholder inbox overview. |
| Profile | src/screens/ProfileScreen.tsx | Student profile summary card. |
| LessonDetail | src/screens/LessonDetailScreen.tsx | Detail view for a selected lesson. |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen for unknown routes. |

## Navigation map
- MainTabs -> Home (default tab)
- Home -> Schedule (tap the search icon)
- Home -> LessonDetail (tap a lesson card)
- Schedule -> LessonDetail (tap a lesson card)
- LessonDetail -> Schedule (tap "Back to Schedule")

## Shared components
- src/components/HeaderBar.tsx — section header with title/subtitle and optional action icon.
- src/components/SubjectCard.tsx — colored subject recommendation card.
- src/components/LessonCard.tsx — lesson information card with primary tap and kebab action.
- src/components/DayChip.tsx — day/date selector pill for the schedule.
- src/components/TimeSlotRow.tsx — layout wrapper for time column + lesson card.
- src/components/IllustrationCard.tsx — hero illustration placeholder for the home screen.

## Design tokens
primary, primaryDark, primaryLight, accent, background, surface, card, border, textPrimary, textSecondary, textDisabled, textInverse, success, warning, error, info, shadowColor
