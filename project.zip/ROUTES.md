# App_RNIOS_Test — Screens & Navigation

## How to run
cd /home/hewlett/projects/frontendX_backend_merged/frontend_runs/run_be5f564f_20260622_054922/project
npm install && npx expo start
# Press 'a' for Android, 'i' for iOS simulator, 'w' for web,
# or scan the QR code with the Expo Go app on a physical iOS/Android device.

## Screens
| Screen | File | Description |
|--------|------|-------------|
| Home | src/screens/HomeScreen.tsx | Premium SaaS hero, CTA, collaboration cards, and insights. |
| Features | src/screens/FeaturesScreen.tsx | Feature cards with analytics/community/automation focus. |
| Pricing | src/screens/PricingScreen.tsx | Starter, Professional, and Enterprise plans with CTA. |
| Testimonials | src/screens/TestimonialsScreen.tsx | Swipeable testimonial carousel with ratings. |
| Resources | src/screens/ResourcesScreen.tsx | Resource list and active highlight. |
| Company | src/screens/CompanyScreen.tsx | Company values and highlights. |
| Contact | src/screens/ContactScreen.tsx | Contact form with validation, reset, and success state. |
| Login | src/screens/LoginScreen.tsx | Email/password login with Google sign-in. |
| NotFound | src/screens/NotFoundScreen.tsx | Fallback screen for invalid routes. |

## Navigation map
- Home -> Pricing (tap "Get Started Free")
- Drawer -> Home / Features / Pricing / Testimonials / Resources / Company / Contact / Login (tap drawer item)

## Shared components
- src/components/HeaderBar.tsx — Sticky header with centered logo and menu button.
- src/components/SectionHeader.tsx — Title/subtitle block for sections.
- src/components/PrimaryButton.tsx — Gradient CTA button.
- src/components/FeatureCard.tsx — Feature card with icon and highlight.
- src/components/TestimonialCard.tsx — Testimonial card with avatar and stars.
- src/components/PricingCard.tsx — Pricing plan card with feature list.
- src/components/ResourceCard.tsx — Resource row card.
- src/components/CompanyValueCard.tsx — Company value card.
- src/components/CollaborationCard.tsx — Horizontal collaboration image card.
- src/components/FormInput.tsx — Labeled TextInput with error support.

## Design tokens
primary, primaryDark, primaryLight, accent, background, surface, card, border, textPrimary, textSecondary, textDisabled, textInverse, success, warning, error, info, shadowColor
