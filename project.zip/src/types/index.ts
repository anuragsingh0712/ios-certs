export type Subject = {
  id: string;
  title: string;
  color: string;
  icon: string;
};

export type Lesson = {
  id: string;
  subjectId: string;
  title: string;
  chapter: string;
  room: string;
  instructor: string;
  startTime: string;
  endTime: string;
  day: string;
  color: string;
};
