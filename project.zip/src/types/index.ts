export type Feature = {
  id: string;
  title: string;
  description: string;
  icon: string;
  highlight: string;
};

export type Testimonial = {
  id: string;
  name: string;
  company: string;
  review: string;
  rating: number;
};

export type PricingPlan = {
  id: string;
  name: string;
  price: string;
  description: string;
  features: string[];
  isHighlighted: boolean;
};

export type CollaborationItem = {
  id: string;
  title: string;
  subtitle: string;
};

export type ResourceItem = {
  id: string;
  title: string;
  description: string;
};

export type CompanyValue = {
  id: string;
  title: string;
  description: string;
};
