export interface User {
  id: string;
  name: string;
  email: string;
  company: string;
  role: string;
}

export interface KPI {
  id: string;
  label: string;
  value: string;
  trend: string;
  delta: string;
  tone: 'success' | 'warning' | 'info';
}

export interface Activity {
  id: string;
  title: string;
  subtitle: string;
  time: string;
  tone: 'success' | 'warning' | 'info';
}

export interface FeatureItem {
  id: string;
  title: string;
  summary: string;
  description: string;
  benefits: string[];
  insights: string[];
  workflows: string[];
  usage: number;
}

export interface PricingPlan {
  id: string;
  name: string;
  priceMonthly: number;
  priceYearly: number;
  description: string;
  features: string[];
  highlighted: boolean;
}

export interface ResourceItem {
  id: string;
  title: string;
  category: 'Article' | 'Tutorial' | 'FAQ' | 'Guide';
  summary: string;
  content: string;
  duration: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  body: string;
  time: string;
  read: boolean;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  review: string;
  rating: number;
  outcome: string;
}

export interface ContactSubmission {
  id: string;
  name: string;
  email: string;
  company: string;
  message: string;
  createdAt: string;
  status: 'success' | 'failed';
}
