import React from 'react';
import { Platform, StyleSheet } from 'react-native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import LoginScreen from '../screens/LoginScreen';
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen';
import HomeScreen from '../screens/HomeScreen';
import DashboardScreen from '../screens/DashboardScreen';
import FeaturesScreen from '../screens/FeaturesScreen';
import FeatureDetailScreen from '../screens/FeatureDetailScreen';
import PricingScreen from '../screens/PricingScreen';
import PlanConfirmationScreen from '../screens/PlanConfirmationScreen';
import ResourcesScreen from '../screens/ResourcesScreen';
import ResourceDetailScreen from '../screens/ResourceDetailScreen';
import ProfileScreen from '../screens/ProfileScreen';
import EditProfileScreen from '../screens/EditProfileScreen';
import ContactScreen from '../screens/ContactScreen';
import NotificationsScreen from '../screens/NotificationsScreen';
import TestimonialsScreen from '../screens/TestimonialsScreen';
import NotFoundScreen from '../screens/NotFoundScreen';

export type RootStackParamList = {
  Login: undefined;
  ForgotPassword: undefined;
  MainTabs: undefined;
  FeatureDetail: { id: string };
  ResourceDetail: { id: string };
  Pricing: undefined;
  PlanConfirmation: undefined;
  Contact: undefined;
  Notifications: undefined;
  Testimonials: undefined;
  EditProfile: undefined;
  NotFound: undefined;
};

export type TabParamList = {
  Home: undefined;
  Dashboard: undefined;
  Features: undefined;
  Resources: undefined;
  Profile: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          borderTopWidth: StyleSheet.hairlineWidth,
          height: Platform.select({ ios: 83, android: 60, default: 60 }),
          paddingBottom: Platform.select({ ios: 28, android: 8, default: 8 }),
          paddingTop: 8,
          ...Platform.select({ android: { elevation: 8 }, ios: {}, default: {} }),
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '500',
          fontFamily: 'Inter-Medium',
        },
        tabBarIcon: ({ color }) => {
          const iconMap: Record<keyof TabParamList, keyof typeof Ionicons.glyphMap> = {
            Home: 'home-outline',
            Dashboard: 'analytics-outline',
            Features: 'layers-outline',
            Resources: 'book-outline',
            Profile: 'person-outline',
          };
          return <Ionicons name={iconMap[route.name]} size={20} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Features" component={FeaturesScreen} />
      <Tab.Screen name="Resources" component={ResourcesScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export function RootNavigator() {
  return (
    <Stack.Navigator
      initialRouteName="Login"
      screenOptions={{
        headerStyle: {
          backgroundColor: colors.surface,
          ...Platform.select({ android: { elevation: 4 }, ios: {}, default: {} }),
        },
        headerTitleStyle: {
          fontFamily: 'Inter-SemiBold',
          fontWeight: '600',
          fontSize: 17,
          color: colors.textPrimary,
          letterSpacing: Platform.select({ ios: -0.4, android: 0, default: 0 }),
        } as any,
        headerTintColor: colors.primary,
        headerBackTitleVisible: false,
        headerShadowVisible: true,
      }}
    >
      <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} options={{ title: 'Reset password' }} />
      <Stack.Screen name="MainTabs" component={MainTabs} options={{ headerShown: false }} />
      <Stack.Screen name="FeatureDetail" component={FeatureDetailScreen} options={{ title: 'Feature detail' }} />
      <Stack.Screen name="ResourceDetail" component={ResourceDetailScreen} options={{ title: 'Resource detail' }} />
      <Stack.Screen name="Pricing" component={PricingScreen} />
      <Stack.Screen name="PlanConfirmation" component={PlanConfirmationScreen} options={{ title: 'Plan confirmed' }} />
      <Stack.Screen name="Contact" component={ContactScreen} options={{ title: 'Contact support' }} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} />
      <Stack.Screen name="Testimonials" component={TestimonialsScreen} />
      <Stack.Screen name="EditProfile" component={EditProfileScreen} options={{ title: 'Edit profile' }} />
      <Stack.Screen name="NotFound" component={NotFoundScreen} options={{ title: 'Not found' }} />
    </Stack.Navigator>
  );
}
