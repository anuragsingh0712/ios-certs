import React from 'react';
import { Pressable, Platform, StyleSheet } from 'react-native';
import { createNativeStackNavigator, NativeStackNavigationOptions } from '@react-navigation/native-stack';
import { createDrawerNavigator, DrawerNavigationOptions } from '@react-navigation/drawer';
import { DrawerActions } from '@react-navigation/native';
import { MaterialIcons } from '@expo/vector-icons';
import HomeScreen from '../screens/HomeScreen';
import FeaturesScreen from '../screens/FeaturesScreen';
import PricingScreen from '../screens/PricingScreen';
import TestimonialsScreen from '../screens/TestimonialsScreen';
import ResourcesScreen from '../screens/ResourcesScreen';
import CompanyScreen from '../screens/CompanyScreen';
import ContactScreen from '../screens/ContactScreen';
import LoginScreen from '../screens/LoginScreen';
import NotFoundScreen from '../screens/NotFoundScreen';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export type RootStackParamList = {
  Home: undefined;
  Features: undefined;
  Pricing: undefined;
  Testimonials: undefined;
  Resources: undefined;
  Company: undefined;
  Contact: undefined;
  Login: undefined;
  NotFound: undefined;
};

export type RootDrawerParamList = {
  Home: undefined;
  Features: undefined;
  Pricing: undefined;
  Testimonials: undefined;
  Resources: undefined;
  Company: undefined;
  Contact: undefined;
  Login: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Drawer = createDrawerNavigator<RootDrawerParamList>();

const stackScreenOptions: NativeStackNavigationOptions = {
  headerStyle: {
    backgroundColor: colors.surface,
    ...Platform.select({ android: { elevation: 4 }, ios: {}, default: {} }),
  },
  headerTitleStyle: {
    fontFamily: 'Inter-SemiBold',
    fontWeight: '600',
    fontSize: 17,
    color: colors.textPrimary,
    letterSpacing: Platform.select({ ios: -0.4, android: 0, default: 0 }),
  } as any,
  headerTintColor: colors.primary,
  headerBackTitleVisible: false,
  headerShadowVisible: true,
};

function MenuButton({ onPress }: { onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.menuButton, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
    >
      <MaterialIcons name="menu" size={s(5)} color={colors.textPrimary} />
    </Pressable>
  );
}

function ScreenStack({
  screenName,
  component,
  title,
  headerShown = true,
}: {
  screenName: keyof RootStackParamList;
  component: React.ComponentType<any>;
  title: string;
  headerShown?: boolean;
}) {
  return (
    <Stack.Navigator screenOptions={stackScreenOptions}>
      <Stack.Screen
        name={screenName}
        component={component}
        options={({ navigation }) => ({
          title,
          headerShown,
          headerLeft: () => <MenuButton onPress={() => navigation.dispatch(DrawerActions.toggleDrawer())} />,
        })}
      />
      <Stack.Screen name="NotFound" component={NotFoundScreen} options={{ title: 'Not Found' }} />
    </Stack.Navigator>
  );
}

export function RootNavigator() {
  const drawerScreenOptions: DrawerNavigationOptions = {
    headerShown: false,
    drawerType: Platform.select({ ios: 'slide', android: 'slide', default: 'front' }),
    overlayColor: 'rgba(0,0,0,0.2)',
    drawerActiveTintColor: colors.primary,
    drawerInactiveTintColor: colors.textSecondary,
    drawerLabelStyle: {
      fontFamily: 'Inter-SemiBold',
      fontSize: s(3),
      letterSpacing: 0.2,
    },
    drawerStyle: {
      backgroundColor: colors.surface,
      width: s(64),
    },
    sceneContainerStyle: {
      backgroundColor: colors.background,
    },
  };

  return (
    <Drawer.Navigator initialRouteName="Home" screenOptions={drawerScreenOptions}>
      <Drawer.Screen name="Home">
        {() => <ScreenStack screenName="Home" component={HomeScreen} title="Home" headerShown={false} />}
      </Drawer.Screen>
      <Drawer.Screen name="Features">
        {() => <ScreenStack screenName="Features" component={FeaturesScreen} title="Features" />}
      </Drawer.Screen>
      <Drawer.Screen name="Pricing">
        {() => <ScreenStack screenName="Pricing" component={PricingScreen} title="Pricing" />}
      </Drawer.Screen>
      <Drawer.Screen name="Testimonials">
        {() => <ScreenStack screenName="Testimonials" component={TestimonialsScreen} title="Testimonials" />}
      </Drawer.Screen>
      <Drawer.Screen name="Resources">
        {() => <ScreenStack screenName="Resources" component={ResourcesScreen} title="Resources" />}
      </Drawer.Screen>
      <Drawer.Screen name="Company">
        {() => <ScreenStack screenName="Company" component={CompanyScreen} title="Company" />}
      </Drawer.Screen>
      <Drawer.Screen name="Contact">
        {() => <ScreenStack screenName="Contact" component={ContactScreen} title="Contact" />}
      </Drawer.Screen>
      <Drawer.Screen name="Login">
        {() => <ScreenStack screenName="Login" component={LoginScreen} title="Login" />}
      </Drawer.Screen>
    </Drawer.Navigator>
  );
}

const styles = StyleSheet.create({
  menuButton: {
    padding: s(1),
    borderRadius: s(2),
  },
});
