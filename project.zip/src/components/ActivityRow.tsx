import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Activity } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface ActivityRowProps {
  item: Activity;
}

export function ActivityRow({ item }: ActivityRowProps) {
  const toneColor = item.tone === 'success' ? colors.success : item.tone === 'warning' ? colors.warning : colors.info;
  return (
    <View style={styles.row}>
      <View style={[styles.dot, { backgroundColor: toneColor }]} />
      <View style={styles.textBlock}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.subtitle}>{item.subtitle}</Text>
      </View>
      <Text style={styles.time}>{item.time}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: s(3),
  },
  dot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    marginRight: s(3),
  },
  textBlock: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  subtitle: {
    marginTop: s(1),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  time: {
    fontSize: 11,
    lineHeight: 15.4,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textDisabled,
    fontFamily: 'Inter-Medium',
  },
});
