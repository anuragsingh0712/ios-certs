import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Lesson } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface LessonCardProps {
  lesson: Lesson;
  onPress: () => void;
  onMorePress: () => void;
  compact?: boolean;
}

export function LessonCard({ lesson, onPress, onMorePress, compact }: LessonCardProps) {
  return (
    <View style={[styles.card, compact && styles.compactCard, { backgroundColor: lesson.color }]}
    >
      <Pressable
        onPress={onPress}
        android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
        style={StyleSheet.absoluteFillObject}
      />
      <View pointerEvents="none" style={styles.content}>
        <Text style={[styles.title, lesson.color !== colors.card && styles.titleInverse]}>{lesson.title}</Text>
        <Text style={[styles.subtitle, lesson.color !== colors.card && styles.subtitleInverse]}>{lesson.chapter}</Text>
        <View style={styles.metaRow}>
          <Ionicons name="location-outline" size={s(4)} color={lesson.color !== colors.card ? colors.textInverse : colors.textSecondary} />
          <Text style={[styles.metaText, lesson.color !== colors.card && styles.metaInverse]}>{lesson.room}</Text>
        </View>
        <View style={styles.metaRow}>
          <Ionicons name="person-outline" size={s(4)} color={lesson.color !== colors.card ? colors.textInverse : colors.textSecondary} />
          <Text style={[styles.metaText, lesson.color !== colors.card && styles.metaInverse]}>{lesson.instructor}</Text>
        </View>
      </View>
      <Pressable
        onPress={onMorePress}
        hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
        android_ripple={{ color: 'rgba(0,0,0,0.08)', borderless: true }}
        style={({ pressed }) => [styles.moreBtn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
      >
        <Ionicons name="ellipsis-vertical" size={s(4)} color={lesson.color !== colors.card ? colors.textInverse : colors.textSecondary} />
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: s(4),
    padding: s(4),
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  compactCard: {
    minHeight: s(22),
  },
  content: {
    gap: s(2),
  },
  title: {
    fontSize: s(4),
    fontWeight: '600',
    color: colors.textPrimary,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: -0.5,
    lineHeight: s(4) * 1.2,
  },
  titleInverse: {
    color: colors.textInverse,
  },
  subtitle: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  subtitleInverse: {
    color: colors.textInverse,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(2),
  },
  metaText: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  metaInverse: {
    color: colors.textInverse,
  },
  moreBtn: {
    position: 'absolute',
    top: s(3),
    right: s(3),
    width: s(6),
    height: s(6),
    borderRadius: s(3),
    alignItems: 'center',
    justifyContent: 'center',
  },
});
