import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Testimonial } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface TestimonialCardProps {
  testimonial: Testimonial;
}

export function TestimonialCard({ testimonial }: TestimonialCardProps) {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={s(5)} color={colors.textInverse} />
        </View>
        <View>
          <Text style={styles.name}>{testimonial.name}</Text>
          <Text style={styles.company}>{testimonial.company}</Text>
        </View>
      </View>
      <Text style={styles.review}>{testimonial.review}</Text>
      <View style={styles.stars}>
        {Array.from({ length: 5 }).map((_, index) => (
          <Ionicons
            key={`star-${testimonial.id}-${index}`}
            name={index < testimonial.rating ? 'star' : 'star-outline'}
            size={s(4)}
            color={colors.accent}
          />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: s(3),
    padding: s(4),
    gap: s(3),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(3),
  },
  avatar: {
    width: s(12),
    height: s(12),
    borderRadius: s(6),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: {
    fontSize: s(3.5),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(3.5) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  company: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  review: {
    fontSize: s(3.25),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3.25) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  stars: {
    flexDirection: 'row',
    gap: s(1),
  },
});
