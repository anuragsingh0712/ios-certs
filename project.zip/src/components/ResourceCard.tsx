import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { ResourceItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface ResourceCardProps {
  item: ResourceItem;
  onPress: () => void;
  bookmarked: boolean;
}

export function ResourceCard({ item, onPress, bookmarked }: ResourceCardProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.card, pressed && Platform.OS === 'ios' && { opacity: 0.9 }]}
    >
      <View style={styles.topRow}>
        <Text style={styles.category}>{item.category}</Text>
        <Text style={styles.bookmark}>{bookmarked ? 'Saved' : 'Save'}</Text>
      </View>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.summary}>{item.summary}</Text>
      <Text style={styles.duration}>{item.duration}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginBottom: s(3),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  category: {
    fontSize: 11,
    lineHeight: 15.4,
    fontWeight: '600',
    letterSpacing: 1.2,
    color: colors.primary,
    textTransform: 'uppercase',
    fontFamily: 'Inter-SemiBold',
  },
  bookmark: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  title: {
    marginTop: s(2),
    fontSize: 16,
    lineHeight: 19.2,
    fontWeight: '600',
    letterSpacing: -0.3,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  summary: {
    marginTop: s(1),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  duration: {
    marginTop: s(2),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textDisabled,
    fontFamily: 'Inter-Medium',
  },
});
