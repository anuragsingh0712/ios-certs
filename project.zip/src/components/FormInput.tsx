import React from 'react';
import { View, Text, TextInput, StyleSheet, Platform } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface FormInputProps {
  label: string;
  value: string;
  placeholder: string;
  onChangeText: (value: string) => void;
  error?: string;
  keyboardType?: 'default' | 'email-address';
  secureTextEntry?: boolean;
  isFocused?: boolean;
  onFocus?: () => void;
  onBlur?: () => void;
  multiline?: boolean;
  numberOfLines?: number;
}

export function FormInput({
  label,
  value,
  placeholder,
  onChangeText,
  error,
  keyboardType = 'default',
  secureTextEntry,
  isFocused,
  onFocus,
  onBlur,
  multiline,
  numberOfLines,
}: FormInputProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value}
        placeholder={placeholder}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        secureTextEntry={secureTextEntry}
        placeholderTextColor={colors.textDisabled}
        autoCapitalize="none"
        autoCorrect={false}
        returnKeyType="done"
        underlineColorAndroid="transparent"
        selectionColor={colors.primary}
        onFocus={onFocus}
        onBlur={onBlur}
        multiline={multiline}
        numberOfLines={numberOfLines}
        style={[styles.input, isFocused && styles.focused, multiline && styles.multiline]}
      />
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    gap: s(1.5),
  },
  label: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.textPrimary,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-SemiBold',
  },
  input: {
    backgroundColor: colors.surface,
    borderRadius: s(2),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    paddingHorizontal: s(3),
    paddingVertical: s(2.5),
    fontSize: s(3.5),
    fontWeight: '500',
    color: colors.textPrimary,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  focused: {
    borderColor: colors.info,
  },
  multiline: {
    minHeight: s(24),
    textAlignVertical: 'top',
  },
  error: {
    fontSize: s(2.75),
    fontWeight: '500',
    color: colors.error,
    letterSpacing: 0.2,
    lineHeight: s(2.75) * 1.4,
    fontFamily: 'Inter-Medium',
  },
});
