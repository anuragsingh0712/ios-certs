import React from 'react';
import { Text, Pressable, StyleSheet, Platform, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface PrimaryButtonProps {
  label: string;
  onPress: () => void;
  style?: ViewStyle;
}

export function PrimaryButton({ label, onPress, style }: PrimaryButtonProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.12)' }}
      style={({ pressed }) => [styles.container, style, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
    >
      <LinearGradient
        colors={[colors.primary, colors.primaryDark]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.gradient}
      >
        <Text style={styles.label}>{label}</Text>
      </LinearGradient>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: s(2),
  },
  gradient: {
    paddingVertical: s(3),
    paddingHorizontal: s(6),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(2),
  },
  label: {
    fontSize: s(3.5),
    fontWeight: '700',
    color: colors.textInverse,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.2,
    fontFamily: 'Inter-Bold',
  },
});
