import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface TextFieldProps {
  label: string;
  value: string;
  onChangeText: (value: string) => void;
  placeholder: string;
  secureTextEntry?: boolean;
  keyboardType?: 'default' | 'email-address';
}

export function TextField({ label, value, onChangeText, placeholder, secureTextEntry, keyboardType }: TextFieldProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.textDisabled}
        secureTextEntry={secureTextEntry}
        autoCapitalize="none"
        autoCorrect={false}
        keyboardType={keyboardType}
        returnKeyType="done"
        underlineColorAndroid="transparent"
        selectionColor={colors.primary}
        style={styles.input}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: s(3),
  },
  label: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    marginBottom: s(2),
    fontFamily: 'Inter-SemiBold',
  },
  input: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    borderRadius: s(2),
    paddingHorizontal: s(3),
    paddingVertical: s(3),
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    backgroundColor: colors.surface,
    fontFamily: 'Inter-Regular',
  },
});
