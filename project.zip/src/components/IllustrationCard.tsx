import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export function IllustrationCard() {
  return (
    <View style={styles.container}>
      <View style={styles.circle}>
        <Ionicons name="planet-outline" size={s(10)} color={colors.primaryLight} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: s(26),
    borderRadius: s(6),
    backgroundColor: colors.primaryDark,
    overflow: 'hidden',
    padding: s(6),
    justifyContent: 'center',
  },
  circle: {
    width: s(20),
    height: s(20),
    borderRadius: s(10),
    backgroundColor: colors.success,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
