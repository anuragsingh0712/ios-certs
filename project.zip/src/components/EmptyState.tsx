import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface EmptyStateProps {
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
}

export function EmptyState({ title, message, actionLabel, onAction }: EmptyStateProps) {
  return (
    <View style={styles.container}>
      <View style={styles.iconWrap}>
        <Ionicons name="sparkles" size={22} color={colors.primary} />
      </View>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.message}>{message}</Text>
      {actionLabel && onAction ? (
        <Pressable
          onPress={onAction}
          android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
          style={({ pressed }) => [styles.action, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
        >
          <Text style={styles.actionText}>{actionLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: s(6),
  },
  iconWrap: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primaryLight,
    marginBottom: s(3),
  },
  title: {
    fontSize: 18,
    lineHeight: 21.6,
    fontWeight: '700',
    letterSpacing: -0.4,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  message: {
    marginTop: s(2),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    textAlign: 'center',
    fontFamily: 'Inter-Regular',
  },
  action: {
    marginTop: s(3),
    paddingHorizontal: s(4),
    paddingVertical: s(2),
    borderRadius: s(2),
    backgroundColor: colors.primary,
  },
  actionText: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textInverse,
    fontFamily: 'Inter-SemiBold',
  },
});
