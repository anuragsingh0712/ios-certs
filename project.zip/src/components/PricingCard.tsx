import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { PricingPlan } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface PricingCardProps {
  plan: PricingPlan;
  selected: boolean;
  onSelect: () => void;
}

export function PricingCard({ plan, selected, onSelect }: PricingCardProps) {
  return (
    <View style={[styles.container, plan.isHighlighted && styles.highlighted, selected && styles.selected]}>
      <View style={styles.header}>
        <Text style={styles.name}>{plan.name}</Text>
        <Text style={styles.price}>{plan.price}</Text>
        <Text style={styles.description}>{plan.description}</Text>
      </View>
      <View style={styles.features}>
        {plan.features.map((feature) => (
          <View key={`${plan.id}-${feature}`} style={styles.featureRow}>
            <MaterialIcons name="check-circle" size={s(4)} color={colors.primary} />
            <Text style={styles.featureText}>{feature}</Text>
          </View>
        ))}
      </View>
      <Pressable
        onPress={onSelect}
        android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
        style={({ pressed }) => [styles.button, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
      >
        <Text style={styles.buttonText}>{selected ? 'Selected' : 'Choose Plan'}</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.card,
    borderRadius: s(3),
    padding: s(4),
    gap: s(4),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(1) },
        shadowOpacity: 0.08,
        shadowRadius: s(2),
      },
      android: { elevation: 6 },
      default: {},
    }),
  },
  highlighted: {
    borderColor: colors.primary,
    backgroundColor: colors.primaryLight,
  },
  selected: {
    borderColor: colors.primaryDark,
  },
  header: {
    gap: s(1.5),
  },
  name: {
    fontSize: s(4),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(4) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  price: {
    fontSize: s(5),
    fontWeight: '700',
    color: colors.primaryDark,
    letterSpacing: -0.5,
    lineHeight: s(5) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  description: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  features: {
    gap: s(2),
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(2),
  },
  featureText: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textPrimary,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  button: {
    backgroundColor: colors.primary,
    paddingVertical: s(2.5),
    borderRadius: s(2),
    alignItems: 'center',
  },
  buttonText: {
    fontSize: s(3),
    fontWeight: '700',
    color: colors.textInverse,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.2,
    fontFamily: 'Inter-Bold',
  },
});
