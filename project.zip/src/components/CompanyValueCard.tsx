import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { CompanyValue } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface CompanyValueCardProps {
  value: CompanyValue;
  onPress: () => void;
}

export function CompanyValueCard({ value, onPress }: CompanyValueCardProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.container, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
    >
      <View style={styles.iconWrap}>
        <MaterialIcons name="verified" size={s(5)} color={colors.accent} />
      </View>
      <View style={styles.content}>
        <Text style={styles.title}>{value.title}</Text>
        <Text style={styles.description}>{value.description}</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    gap: s(3),
    padding: s(3),
    borderRadius: s(3),
    backgroundColor: colors.card,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(1) },
        shadowOpacity: 0.08,
        shadowRadius: s(2),
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  iconWrap: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    backgroundColor: colors.primaryDark,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    gap: s(1),
  },
  title: {
    fontSize: s(3.5),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(3.5) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  description: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-Medium',
  },
});
