import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface TimeSlotRowProps {
  startTime: string;
  endTime: string;
  children: React.ReactNode;
}

export function TimeSlotRow({ startTime, endTime, children }: TimeSlotRowProps) {
  return (
    <View style={styles.row}>
      <View style={styles.timeCol}>
        <Text style={styles.start}>{startTime}</Text>
        <Text style={styles.end}>{endTime}</Text>
      </View>
      <View style={styles.cardCol}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: s(3),
  },
  timeCol: {
    width: s(12),
    paddingTop: s(2),
  },
  start: {
    fontSize: s(4),
    fontWeight: '600',
    color: colors.textPrimary,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: 0.2,
    lineHeight: s(4) * 1.4,
  },
  end: {
    marginTop: s(1),
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textDisabled,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  cardCol: {
    flex: 1,
  },
});
