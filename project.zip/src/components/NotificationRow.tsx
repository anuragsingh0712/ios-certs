import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { NotificationItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface NotificationRowProps {
  item: NotificationItem;
  onToggleRead: () => void;
  onDismiss: () => void;
}

export function NotificationRow({ item, onToggleRead, onDismiss }: NotificationRowProps) {
  return (
    <View style={[styles.card, item.read && styles.cardRead]}>
      <Pressable
        onPress={onToggleRead}
        android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
        style={({ pressed }) => [styles.pressArea, pressed && Platform.OS === 'ios' && { opacity: 0.9 }]}
      >
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.body}>{item.body}</Text>
        <Text style={styles.time}>{item.time}</Text>
      </Pressable>
      <Pressable
        onPress={onDismiss}
        android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
        style={({ pressed }) => [styles.dismiss, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        <Text style={styles.dismissText}>Dismiss</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginBottom: s(3),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  cardRead: {
    backgroundColor: colors.primaryLight,
  },
  pressArea: {
    flex: 1,
  },
  title: {
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  body: {
    marginTop: s(1),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  time: {
    marginTop: s(2),
    fontSize: 11,
    lineHeight: 15.4,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textDisabled,
    fontFamily: 'Inter-Medium',
  },
  dismiss: {
    alignSelf: 'flex-start',
    marginTop: s(2),
    paddingHorizontal: s(2),
    paddingVertical: s(1),
    borderRadius: s(2),
    backgroundColor: colors.surface,
  },
  dismissText: {
    fontSize: 11,
    lineHeight: 15.4,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-SemiBold',
  },
});
