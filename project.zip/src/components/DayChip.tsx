import React from 'react';
import { Pressable, Text, StyleSheet, Platform } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface DayChipProps {
  label: string;
  date: string;
  active?: boolean;
  onPress: () => void;
}

export function DayChip({ label, date, active, onPress }: DayChipProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [
        styles.container,
        active && styles.activeContainer,
        pressed && Platform.OS === 'ios' && { opacity: 0.7 },
      ]}
    >
      <Text style={[styles.label, active && styles.activeText]}>{label}</Text>
      <Text style={[styles.date, active && styles.activeText]}>{date}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    width: s(10),
    height: s(13),
    borderRadius: s(5),
    alignItems: 'center',
    justifyContent: 'center',
    gap: s(1),
  },
  activeContainer: {
    backgroundColor: colors.primary,
  },
  label: {
    fontSize: s(2),
    fontWeight: '600',
    color: colors.textSecondary,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: 1.2,
    lineHeight: s(2) * 1.2,
  },
  date: {
    fontSize: s(3),
    fontWeight: '700',
    color: colors.textPrimary,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    lineHeight: s(3) * 1.2,
  },
  activeText: {
    color: colors.textInverse,
  },
});
