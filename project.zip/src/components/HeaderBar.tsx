import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface HeaderBarProps {
  title: string;
  onMenuPress?: () => void;
  showMenu?: boolean;
}

export function HeaderBar({ title, onMenuPress, showMenu = true }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <View style={styles.side}>
        {showMenu ? (
          <Pressable
            onPress={onMenuPress}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.menuButton, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
            hitSlop={{ top: s(2), bottom: s(2), left: s(2), right: s(2) }}
          >
            <MaterialIcons name="menu" size={s(6)} color={colors.textPrimary} />
          </Pressable>
        ) : (
          <View style={styles.menuPlaceholder} />
        )}
      </View>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.side} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    height: s(14),
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    paddingHorizontal: s(4),
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(0.5) },
        shadowOpacity: 0.08,
        shadowRadius: s(1.5),
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  side: {
    width: s(10),
    alignItems: 'flex-start',
  },
  title: {
    flex: 1,
    textAlign: 'center',
    fontSize: s(5),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(5) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  menuButton: {
    padding: s(1),
    borderRadius: s(2),
  },
  menuPlaceholder: {
    width: s(6),
    height: s(6),
  },
});
