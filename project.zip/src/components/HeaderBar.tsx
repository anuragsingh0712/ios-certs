import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface HeaderBarProps {
  title: string;
  subtitle?: string;
  actionIcon?: keyof typeof Ionicons.glyphMap;
  onActionPress?: () => void;
}

export function HeaderBar({ title, subtitle, actionIcon, onActionPress }: HeaderBarProps) {
  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.title}>{title}</Text>
        {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
      </View>
      {actionIcon ? (
        <Pressable
          onPress={onActionPress}
          android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
          style={({ pressed }) => [styles.actionBtn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
        >
          <Ionicons name={actionIcon} size={s(5)} color={colors.textPrimary} />
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontSize: s(6),
    fontWeight: '700',
    color: colors.textPrimary,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    lineHeight: s(6) * 1.2,
  },
  subtitle: {
    marginTop: s(1),
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  actionBtn: {
    width: s(8),
    height: s(8),
    borderRadius: s(4),
    backgroundColor: colors.surface,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
