import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { KPI } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface KpiCardProps {
  item: KPI;
}

export function KpiCard({ item }: KpiCardProps) {
  const toneColor = item.tone === 'success' ? colors.success : item.tone === 'warning' ? colors.warning : colors.info;
  return (
    <View style={styles.card}>
      <Text style={styles.label}>{item.label}</Text>
      <Text style={styles.value}>{item.value}</Text>
      <View style={styles.deltaRow}>
        <View style={[styles.dot, { backgroundColor: toneColor }]} />
        <Text style={styles.delta}>{item.delta} vs last</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: s(28),
    padding: s(3),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginRight: s(3),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 6,
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  label: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 1.2,
    color: colors.textSecondary,
    textTransform: 'uppercase',
    fontFamily: 'Inter-Medium',
  },
  value: {
    marginTop: s(2),
    fontSize: 22,
    lineHeight: 26.4,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  deltaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: s(2),
  },
  dot: {
    width: s(1),
    height: s(1),
    borderRadius: s(1),
    marginRight: s(2),
  },
  delta: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
});
