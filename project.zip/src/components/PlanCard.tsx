import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { PricingPlan } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface PlanCardProps {
  plan: PricingPlan;
  price: string;
  selected: boolean;
  onSelect: () => void;
}

export function PlanCard({ plan, price, selected, onSelect }: PlanCardProps) {
  return (
    <Pressable
      onPress={onSelect}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.card, selected && styles.cardSelected, pressed && Platform.OS === 'ios' && { opacity: 0.9 }]}
    >
      <View style={styles.header}>
        <Text style={styles.title}>{plan.name}</Text>
        {plan.highlighted ? <Text style={styles.badge}>Popular</Text> : null}
      </View>
      <Text style={styles.price}>{price}</Text>
      <Text style={styles.description}>{plan.description}</Text>
      {plan.features.map((feature) => (
        <Text key={feature} style={styles.feature}>• {feature}</Text>
      ))}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    borderWidth: s(0),
    borderColor: colors.primary,
    marginBottom: s(3),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 6,
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  cardSelected: {
    borderWidth: s(0.5),
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  title: {
    fontSize: 18,
    lineHeight: 21.6,
    fontWeight: '700',
    letterSpacing: -0.4,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  badge: {
    fontSize: 11,
    lineHeight: 15.4,
    fontWeight: '600',
    letterSpacing: 1.2,
    color: colors.textInverse,
    backgroundColor: colors.primary,
    paddingHorizontal: s(2),
    paddingVertical: s(1),
    borderRadius: s(2),
    textTransform: 'uppercase',
    fontFamily: 'Inter-SemiBold',
  },
  price: {
    marginTop: s(2),
    fontSize: 24,
    lineHeight: 28.8,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  description: {
    marginTop: s(1),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  feature: {
    marginTop: s(2),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-Medium',
  },
});
