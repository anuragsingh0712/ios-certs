import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Subject } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface SubjectCardProps {
  subject: Subject;
  onPress: () => void;
}

export function SubjectCard({ subject, onPress }: SubjectCardProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.12)' }}
      style={({ pressed }) => [
        styles.container,
        { backgroundColor: subject.color },
        pressed && Platform.OS === 'ios' && { opacity: 0.8 },
      ]}
    >
      <View style={styles.iconWrap}>
        <Ionicons name={subject.icon as keyof typeof Ionicons.glyphMap} size={s(5)} color={colors.textInverse} />
      </View>
      <Text style={styles.title}>{subject.title}</Text>
      <Ionicons name="ellipsis-horizontal" size={s(4)} color={colors.textInverse} style={styles.kebab} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    width: s(20),
    height: s(20),
    borderRadius: s(4),
    padding: s(4),
    justifyContent: 'space-between',
    marginRight: s(4),
  },
  iconWrap: {
    width: s(8),
    height: s(8),
    borderRadius: s(4),
    backgroundColor: 'rgba(255,255,255,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.textInverse,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  kebab: {
    alignSelf: 'flex-end',
  },
});
