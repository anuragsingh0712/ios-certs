import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { FeatureItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface FeatureCardProps {
  item: FeatureItem;
  onPress: () => void;
}

export function FeatureCard({ item, onPress }: FeatureCardProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.card, pressed && Platform.OS === 'ios' && { opacity: 0.9 }]}
    >
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.summary}>{item.summary}</Text>
      <View style={styles.usageRow}>
        <View style={styles.usageTrack}>
          <View style={[styles.usageFill, { width: `${item.usage}%` }]} />
        </View>
        <Text style={styles.usageText}>{item.usage}% adoption</Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginBottom: s(3),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  title: {
    fontSize: 16,
    lineHeight: 19.2,
    fontWeight: '600',
    letterSpacing: -0.3,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  summary: {
    marginTop: s(1),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  usageRow: {
    marginTop: s(3),
  },
  usageTrack: {
    height: s(1),
    borderRadius: s(1),
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  usageFill: {
    height: s(1),
    backgroundColor: colors.primary,
    borderRadius: s(1),
  },
  usageText: {
    marginTop: s(2),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
});
