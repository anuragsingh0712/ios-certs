import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';
import { Feature } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface FeatureCardProps {
  feature: Feature;
  selected: boolean;
  onPress: () => void;
}

export function FeatureCard({ feature, selected, onPress }: FeatureCardProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.container, selected && styles.selected, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
    >
      <View style={styles.iconWrap}>
        <MaterialIcons name={feature.icon as keyof typeof MaterialIcons.glyphMap} size={s(6)} color={colors.primary} />
      </View>
      <View style={styles.content}>
        <Text style={styles.title}>{feature.title}</Text>
        <Text style={styles.description}>{feature.description}</Text>
        <View style={styles.highlightBadge}>
          <Text style={styles.highlightText}>{feature.highlight}</Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: colors.card,
    padding: s(3),
    borderRadius: s(3),
    gap: s(3),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(1) },
        shadowOpacity: 0.08,
        shadowRadius: s(2),
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  selected: {
    borderColor: colors.primary,
  },
  iconWrap: {
    width: s(12),
    height: s(12),
    borderRadius: s(6),
    backgroundColor: colors.primaryLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    flex: 1,
    gap: s(1.5),
  },
  title: {
    fontSize: s(4),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(4) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  description: {
    fontSize: s(3.25),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3.25) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  highlightBadge: {
    alignSelf: 'flex-start',
    backgroundColor: colors.accent,
    borderRadius: s(2),
    paddingVertical: s(1),
    paddingHorizontal: s(2),
  },
  highlightText: {
    fontSize: s(2.5),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: 1.2,
    lineHeight: s(2.5) * 1.2,
    fontFamily: 'Inter-Bold',
    textTransform: 'uppercase',
  },
});
