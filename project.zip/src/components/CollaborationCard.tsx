import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { CollaborationItem } from '../types';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface CollaborationCardProps {
  item: CollaborationItem;
  onPress: () => void;
}

export function CollaborationCard({ item, onPress }: CollaborationCardProps) {
  return (
    <Pressable
      onPress={onPress}
      android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
      style={({ pressed }) => [styles.container, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
    >
      <View style={styles.imagePlaceholder}>
        <Ionicons name="image-outline" size={s(6)} color={colors.textDisabled} />
      </View>
      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.subtitle}>{item.subtitle}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    width: s(48),
    padding: s(3),
    backgroundColor: colors.card,
    borderRadius: s(3),
    gap: s(2),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(1) },
        shadowOpacity: 0.08,
        shadowRadius: s(2),
      },
      android: { elevation: 6 },
      default: {},
    }),
  },
  imagePlaceholder: {
    height: s(24),
    borderRadius: s(3),
    backgroundColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: s(3.5),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(3.5) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-Medium',
  },
});
