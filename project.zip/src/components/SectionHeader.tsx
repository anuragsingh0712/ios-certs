import React from 'react';
import { View, Text, Pressable, StyleSheet, Platform } from 'react-native';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

interface SectionHeaderProps {
  title: string;
  actionLabel?: string;
  onActionPress?: () => void;
}

export function SectionHeader({ title, actionLabel, onActionPress }: SectionHeaderProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      {actionLabel && onActionPress ? (
        <Pressable
          onPress={onActionPress}
          android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
          style={({ pressed }) => [styles.action, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
        >
          <Text style={styles.actionText}>{actionLabel}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: s(3),
  },
  title: {
    fontSize: 18,
    lineHeight: 21.6,
    fontWeight: '600',
    letterSpacing: -0.3,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  action: {
    paddingHorizontal: s(2),
    paddingVertical: s(1),
    borderRadius: s(2),
  },
  actionText: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.primary,
    fontFamily: 'Inter-Medium',
  },
});
