import React, { useState } from 'react';
import { View, Text, StyleSheet, Platform, KeyboardAvoidingView, ScrollView, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { PrimaryButton } from '../components/PrimaryButton';
import { TextField } from '../components/TextField';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { ContactSubmission } from '../types';
import { useAppContext } from '../../App';

const simulateDelay = async <T,>(value: T, delay = 700) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const contactRepository = {
  submit: async (payload: ContactSubmission) => payload,
};

const contactService = {
  submit: async (payload: ContactSubmission) => {
    if (Math.random() < 0.2) {
      throw new Error('Network error');
    }
    return simulateDelay(await contactRepository.submit(payload));
  },
};

export default function ContactScreen() {
  const { addContactSubmission } = useAppContext();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = async () => {
    if (!name || !email || !message) {
      setStatus('error');
      return;
    }
    setStatus('loading');
    try {
      const payload: ContactSubmission = {
        id: `contact-${Date.now()}`,
        name,
        email,
        company,
        message,
        createdAt: new Date().toISOString(),
        status: 'success',
      };
      const result = await contactService.submit(payload);
      addContactSubmission(result);
      setName('');
      setEmail('');
      setCompany('');
      setMessage('');
      setStatus('success');
    } catch (err) {
      setStatus('error');
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <Text style={styles.title}>Contact support</Text>
          <Text style={styles.subtitle}>Tell us how we can help and we will respond quickly.</Text>
          <TextField label="Name" value={name} onChangeText={setName} placeholder="Full name" />
          <TextField label="Email" value={email} onChangeText={setEmail} placeholder="name@company.com" keyboardType="email-address" />
          <TextField label="Company" value={company} onChangeText={setCompany} placeholder="Company" />
          <View style={styles.messageBlock}>
            <Text style={styles.label}>Message</Text>
            <TextInput
              value={message}
              onChangeText={setMessage}
              placeholder="How can we help?"
              placeholderTextColor={colors.textDisabled}
              autoCapitalize="sentences"
              autoCorrect
              underlineColorAndroid="transparent"
              selectionColor={colors.primary}
              multiline
              style={styles.messageInput}
            />
          </View>
          {status === 'success' ? <Text style={styles.success}>Message sent successfully.</Text> : null}
          {status === 'error' ? <Text style={styles.error}>Please complete all fields or try again.</Text> : null}
          <PrimaryButton label={status === 'loading' ? 'Sending...' : 'Send message'} onPress={handleSubmit} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  flex: {
    flex: 1,
  },
  content: {
    padding: s(4),
  },
  title: {
    fontSize: 22,
    lineHeight: 26.4,
    fontWeight: '700',
    letterSpacing: -0.4,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    marginTop: s(2),
    marginBottom: s(4),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  messageBlock: {
    marginBottom: s(3),
  },
  label: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    marginBottom: s(2),
    fontFamily: 'Inter-SemiBold',
  },
  messageInput: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    borderRadius: s(2),
    paddingHorizontal: s(3),
    paddingVertical: s(3),
    minHeight: s(20),
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    backgroundColor: colors.surface,
    fontFamily: 'Inter-Regular',
  },
  success: {
    marginBottom: s(2),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.success,
    fontFamily: 'Inter-Medium',
  },
  error: {
    marginBottom: s(2),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.error,
    fontFamily: 'Inter-Medium',
  },
});
