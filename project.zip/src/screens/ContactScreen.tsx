import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, StyleSheet, Platform, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { StatusBar } from 'expo-status-bar';
import { FormInput } from '../components/FormInput';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function ContactScreen() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [message, setMessage] = useState('');
  const [success, setSuccess] = useState('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [focusedField, setFocusedField] = useState<string>('');

  const validate = () => {
    const nextErrors: { [key: string]: string } = {};
    if (!name.trim()) nextErrors.name = 'Name is required.';
    if (!email.includes('@')) nextErrors.email = 'Enter a valid email.';
    if (!company.trim()) nextErrors.company = 'Company is required.';
    if (message.trim().length < 8) nextErrors.message = 'Message must be at least 8 characters.';
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) {
      setSuccess('Thanks! Our team will reach out within 24 hours.');
    } else {
      setSuccess('');
    }
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setCompany('');
    setMessage('');
    setErrors({});
    setSuccess('');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.keyboard}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}
      >
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <Animated.View entering={FadeInUp.duration(400)} style={styles.header}>
            <Text style={styles.title}>Contact</Text>
            <Text style={styles.subtitle}>Let’s design a success plan tailored to your team.</Text>
          </Animated.View>
          <View style={styles.form}>
            <FormInput
              label="Name"
              value={name}
              placeholder="Your full name"
              onChangeText={setName}
              error={errors.name}
              isFocused={focusedField === 'name'}
              onFocus={() => setFocusedField('name')}
              onBlur={() => setFocusedField('')}
            />
            <FormInput
              label="Email"
              value={email}
              placeholder="you@company.com"
              onChangeText={setEmail}
              error={errors.email}
              keyboardType="email-address"
              isFocused={focusedField === 'email'}
              onFocus={() => setFocusedField('email')}
              onBlur={() => setFocusedField('')}
            />
            <FormInput
              label="Company"
              value={company}
              placeholder="Company name"
              onChangeText={setCompany}
              error={errors.company}
              isFocused={focusedField === 'company'}
              onFocus={() => setFocusedField('company')}
              onBlur={() => setFocusedField('')}
            />
            <FormInput
              label="Message"
              value={message}
              placeholder="Tell us about your goals"
              onChangeText={setMessage}
              error={errors.message}
              multiline
              numberOfLines={5}
              isFocused={focusedField === 'message'}
              onFocus={() => setFocusedField('message')}
              onBlur={() => setFocusedField('')}
            />
            {success ? <Text style={styles.success}>{success}</Text> : null}
          </View>
          <View style={styles.actions}>
            <Pressable
              onPress={handleSubmit}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.primaryButton, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
            >
              <Text style={styles.primaryText}>Submit</Text>
            </Pressable>
            <Pressable
              onPress={handleReset}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.secondaryButton, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
            >
              <Text style={styles.secondaryText}>Reset</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  keyboard: {
    flex: 1,
  },
  content: {
    padding: s(4),
    paddingBottom: s(8),
    gap: s(4),
  },
  header: {
    gap: s(2),
  },
  title: {
    fontSize: s(6),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(6) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    fontSize: s(3.5),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  form: {
    gap: s(3),
  },
  success: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.success,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-SemiBold',
  },
  actions: {
    gap: s(3),
  },
  primaryButton: {
    backgroundColor: colors.primary,
    paddingVertical: s(3),
    borderRadius: s(2),
    alignItems: 'center',
  },
  primaryText: {
    fontSize: s(3.5),
    fontWeight: '700',
    color: colors.textInverse,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  secondaryButton: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    paddingVertical: s(3),
    borderRadius: s(2),
    alignItems: 'center',
  },
  secondaryText: {
    fontSize: s(3.5),
    fontWeight: '600',
    color: colors.textPrimary,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.2,
    fontFamily: 'Inter-SemiBold',
  },
});
