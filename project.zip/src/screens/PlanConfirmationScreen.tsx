import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { PrimaryButton } from '../components/PrimaryButton';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { useAppContext } from '../../App';
import { mockPlans } from '../data/mockData';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';

export default function PlanConfirmationScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'PlanConfirmation'>>();
  const { selectedPlanId } = useAppContext();
  const plan = mockPlans.find((item) => item.id === selectedPlanId) || mockPlans[0];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.container}>
        <Text style={styles.title}>Plan confirmed</Text>
        <Text style={styles.subtitle}>You are now on the {plan.name} plan.</Text>
        <View style={styles.card}>
          <Text style={styles.planName}>{plan.name}</Text>
          <Text style={styles.planDescription}>{plan.description}</Text>
          {plan.features.map((feature) => (
            <Text key={feature} style={styles.feature}>• {feature}</Text>
          ))}
        </View>
        <PrimaryButton label="Back to profile" onPress={() => navigation.navigate('MainTabs')} />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  container: {
    flex: 1,
    padding: s(4),
  },
  title: {
    fontSize: 24,
    lineHeight: 28.8,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    marginTop: s(2),
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  card: {
    marginTop: s(4),
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  planName: {
    fontSize: 18,
    lineHeight: 21.6,
    fontWeight: '700',
    letterSpacing: -0.4,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  planDescription: {
    marginTop: s(2),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  feature: {
    marginTop: s(2),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-Medium',
  },
});
