import React, { useState } from 'react';
import { View, Text, StyleSheet, Platform, KeyboardAvoidingView, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { TextField } from '../components/TextField';
import { PrimaryButton } from '../components/PrimaryButton';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { useAppContext } from '../../App';

export default function EditProfileScreen() {
  const { user, updateUser } = useAppContext();
  const [name, setName] = useState(user.name);
  const [company, setCompany] = useState(user.company);
  const [status, setStatus] = useState<'idle' | 'success'>('idle');

  const handleSave = () => {
    updateUser({ name, company });
    setStatus('success');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <Text style={styles.title}>Edit profile</Text>
          <Text style={styles.subtitle}>Update your public workspace details.</Text>
          <TextField label="Full name" value={name} onChangeText={setName} placeholder="Name" />
          <TextField label="Company" value={company} onChangeText={setCompany} placeholder="Company" />
          {status === 'success' ? <Text style={styles.success}>Profile updated successfully.</Text> : null}
          <PrimaryButton label="Save changes" onPress={handleSave} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  flex: {
    flex: 1,
  },
  content: {
    padding: s(4),
  },
  title: {
    fontSize: 22,
    lineHeight: 26.4,
    fontWeight: '700',
    letterSpacing: -0.4,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    marginTop: s(2),
    marginBottom: s(4),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  success: {
    marginBottom: s(3),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.success,
    fontFamily: 'Inter-Medium',
  },
});
