import React, { useCallback, useEffect, useState } from 'react';
import { View, StyleSheet, Platform, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { HeaderBar } from '../components/HeaderBar';
import { FeatureCard } from '../components/FeatureCard';
import { EmptyState } from '../components/EmptyState';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { mockFeatures } from '../data/mockData';
import { FeatureItem } from '../types';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';

const simulateDelay = async <T,>(value: T, delay = 600) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const featureRepository = {
  list: async () => mockFeatures,
};

const featureService = {
  list: async () => simulateDelay(await featureRepository.list()),
};

const useFeatures = () => {
  const [items, setItems] = useState<FeatureItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const data = await featureService.list();
      setItems(data);
      setLoading(false);
    } catch (err) {
      setError(true);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { items, loading, error, reload: load };
};

export default function FeaturesScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'MainTabs'>>();
  const { items, loading, error, reload } = useFeatures();

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={items}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <FeatureCard item={item} onPress={() => navigation.navigate('FeatureDetail', { id: item.id })} />
        )}
        style={styles.list}
        ListHeaderComponent={
          <View>
            <HeaderBar title="Feature suite" subtitle="Explore the products powering your SaaS." />
            {loading ? <View style={styles.loadingCard} /> : null}
            {error ? (
              <EmptyState title="Features offline" message="We could not load feature insights." actionLabel="Retry" onAction={reload} />
            ) : null}
          </View>
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: s(4),
  },
  loadingCard: {
    height: s(20),
    borderRadius: s(3),
    backgroundColor: colors.primaryLight,
    marginBottom: s(3),
  },
  separator: {
    height: s(2),
  },
});
