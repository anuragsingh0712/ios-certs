import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { StatusBar } from 'expo-status-bar';
import { FeatureCard } from '../components/FeatureCard';
import { SectionHeader } from '../components/SectionHeader';
import { features } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function FeaturesScreen() {
  const [selectedId, setSelectedId] = useState(features[0]?.id ?? '');

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={features}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <FeatureCard feature={item} selected={selectedId === item.id} onPress={() => setSelectedId(item.id)} />
        )}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <Animated.View entering={FadeInDown.duration(400)} style={styles.header}>
            <SectionHeader
              title="Features"
              subtitle="Actionable analytics, community signals, and automation at enterprise scale."
            />
            <Text style={styles.selected}>Active focus: {features.find((item) => item.id === selectedId)?.title}</Text>
          </Animated.View>
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  content: {
    padding: s(4),
    paddingBottom: s(8),
  },
  header: {
    gap: s(3),
    marginBottom: s(4),
  },
  selected: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.primaryDark,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-SemiBold',
  },
  separator: {
    height: s(3),
  },
});
