import React, { useState } from 'react';
import { View, Text, ScrollView, KeyboardAvoidingView, StyleSheet, Platform, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { StatusBar } from 'expo-status-bar';
import { FormInput } from '../components/FormInput';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [focusedField, setFocusedField] = useState<string>('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [status, setStatus] = useState('');

  const handleLogin = () => {
    const nextErrors: { [key: string]: string } = {};
    if (!email.includes('@')) nextErrors.email = 'Enter a valid email.';
    if (password.length < 6) nextErrors.password = 'Password must be at least 6 characters.';
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length === 0) {
      setStatus('Login success. Welcome back.');
    } else {
      setStatus('');
    }
  };

  const handleGoogle = () => {
    setStatus('Google sign-in initiated.');
  };

  const handleForgot = () => {
    setStatus('Password reset link sent.');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.keyboard}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : s(5)}
      >
        <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
          <Animated.View entering={FadeInUp.duration(400)} style={styles.header}>
            <Text style={styles.title}>Login</Text>
            <Text style={styles.subtitle}>Access your analytics workspace.</Text>
          </Animated.View>
          <View style={styles.form}>
            <FormInput
              label="Email"
              value={email}
              placeholder="you@company.com"
              onChangeText={setEmail}
              error={errors.email}
              keyboardType="email-address"
              isFocused={focusedField === 'email'}
              onFocus={() => setFocusedField('email')}
              onBlur={() => setFocusedField('')}
            />
            <FormInput
              label="Password"
              value={password}
              placeholder="Password"
              onChangeText={setPassword}
              error={errors.password}
              secureTextEntry
              isFocused={focusedField === 'password'}
              onFocus={() => setFocusedField('password')}
              onBlur={() => setFocusedField('')}
            />
            <Pressable
              onPress={handleForgot}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.forgotButton, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
            >
              <Text style={styles.forgotText}>Forgot Password</Text>
            </Pressable>
          </View>
          {status ? <Text style={styles.status}>{status}</Text> : null}
          <View style={styles.actions}>
            <Pressable
              onPress={handleLogin}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.primaryButton, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
            >
              <Text style={styles.primaryText}>Login</Text>
            </Pressable>
            <Pressable
              onPress={handleGoogle}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.googleButton, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
            >
              <Text style={styles.googleText}>Continue with Google</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  keyboard: {
    flex: 1,
  },
  content: {
    padding: s(4),
    paddingBottom: s(8),
    gap: s(4),
  },
  header: {
    gap: s(2),
  },
  title: {
    fontSize: s(6),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(6) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    fontSize: s(3.5),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  form: {
    gap: s(3),
  },
  forgotButton: {
    alignSelf: 'flex-end',
    paddingVertical: s(1),
  },
  forgotText: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.info,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-SemiBold',
  },
  status: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.success,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-SemiBold',
  },
  actions: {
    gap: s(3),
  },
  primaryButton: {
    backgroundColor: colors.primary,
    paddingVertical: s(3),
    borderRadius: s(2),
    alignItems: 'center',
  },
  primaryText: {
    fontSize: s(3.5),
    fontWeight: '700',
    color: colors.textInverse,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  googleButton: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    paddingVertical: s(3),
    borderRadius: s(2),
    alignItems: 'center',
  },
  googleText: {
    fontSize: s(3.5),
    fontWeight: '600',
    color: colors.textPrimary,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.2,
    fontFamily: 'Inter-SemiBold',
  },
});
