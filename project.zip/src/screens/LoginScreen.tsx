import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, StyleSheet, Platform, KeyboardAvoidingView, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { TextField } from '../components/TextField';
import { PrimaryButton } from '../components/PrimaryButton';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { mockUser } from '../data/mockData';
import { User } from '../types';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';
import { useAppContext } from '../../App';

const demoCredentials = {
  email: 'demo@saasify.io',
  password: 'Password123',
};

const simulateDelay = async <T,>(value: T, delay = 700) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const authRepository = {
  login: async (email: string, password: string): Promise<User> => {
    if (email === demoCredentials.email && password === demoCredentials.password) {
      return mockUser;
    }
    throw new Error('Invalid credentials');
  },
};

const authService = {
  login: async (email: string, password: string) => {
    const user = await authRepository.login(email, password);
    return simulateDelay(user);
  },
};

const useAuthWorkflow = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const login = async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    try {
      const user = await authService.login(email, password);
      setLoading(false);
      return { ok: true, user } as const;
    } catch (err) {
      setLoading(false);
      setError('Email or password is incorrect.');
      return { ok: false } as const;
    }
  };

  return { login, loading, error, setError };
};

export default function LoginScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Login'>>();
  const { setSession, setUser, session } = useAppContext();
  const { login, loading, error, setError } = useAuthWorkflow();
  const [email, setEmail] = useState(demoCredentials.email);
  const [password, setPassword] = useState(demoCredentials.password);

  useEffect(() => {
    if (session) {
      navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
    }
  }, [session, navigation]);

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Please enter both email and password.');
      return;
    }
    const result = await login(email, password);
    if (result.ok) {
      setUser(result.user);
      setSession(true);
      navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <View style={styles.iconWrap}>
              <Ionicons name="sparkles" size={28} color={colors.primary} />
            </View>
            <Text style={styles.title}>Welcome back</Text>
            <Text style={styles.subtitle}>Sign in to continue your SaaS workspace.</Text>
          </View>
          <TextField label="Email" value={email} onChangeText={setEmail} placeholder="name@company.com" keyboardType="email-address" />
          <TextField label="Password" value={password} onChangeText={setPassword} placeholder="••••••••" secureTextEntry />
          {error ? <Text style={styles.error}>{error}</Text> : null}
          <PrimaryButton label={loading ? 'Signing in...' : 'Sign In'} onPress={handleLogin} />
          <Pressable
            onPress={() => navigation.navigate('ForgotPassword')}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.link, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
          >
            <Text style={styles.linkText}>Forgot password?</Text>
          </Pressable>
          <View style={styles.dividerRow}>
            <View style={styles.divider} />
            <Text style={styles.dividerText}>Or continue with</Text>
            <View style={styles.divider} />
          </View>
          <View style={styles.socialRow}>
            <Pressable
              onPress={() => setError('Apple sign-in is coming soon.')}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.socialBtn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
            >
              <Ionicons name="logo-apple" size={18} color={colors.textPrimary} />
              <Text style={styles.socialText}>Apple</Text>
            </Pressable>
            <Pressable
              onPress={() => setError('Google sign-in is coming soon.')}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.socialBtn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
            >
              <Ionicons name="logo-google" size={18} color={colors.textPrimary} />
              <Text style={styles.socialText}>Google</Text>
            </Pressable>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  flex: {
    flex: 1,
  },
  scrollContent: {
    padding: s(4),
  },
  header: {
    alignItems: 'flex-start',
    marginBottom: s(6),
  },
  iconWrap: {
    width: s(12),
    height: s(12),
    borderRadius: s(6),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.primaryLight,
    marginBottom: s(4),
  },
  title: {
    fontSize: 26,
    lineHeight: 31.2,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    marginTop: s(2),
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  error: {
    marginBottom: s(2),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.error,
    fontFamily: 'Inter-Medium',
  },
  link: {
    alignItems: 'center',
    marginTop: s(3),
  },
  linkText: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.primary,
    fontFamily: 'Inter-SemiBold',
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: s(5),
  },
  divider: {
    flex: 1,
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
  },
  dividerText: {
    marginHorizontal: s(2),
    fontSize: 11,
    lineHeight: 15.4,
    fontWeight: '500',
    letterSpacing: 1.2,
    color: colors.textDisabled,
    textTransform: 'uppercase',
    fontFamily: 'Inter-Medium',
  },
  socialRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: s(3),
  },
  socialBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: s(3),
    borderRadius: s(2),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    backgroundColor: colors.surface,
    gap: s(2),
  },
  socialText: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
});
