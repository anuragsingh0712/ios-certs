import React from 'react';
import { View, Text, StyleSheet, Platform, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { RootStackParamList } from '../navigation';
import { lessons } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function LessonDetailScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'LessonDetail'>>();
  const route = useRoute<RouteProp<RootStackParamList, 'LessonDetail'>>();
  const lesson = lessons.find((item) => item.id === route.params.id);

  if (!lesson) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar style="dark" />
        <Text style={styles.title}>Lesson not found</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={[styles.hero, { backgroundColor: lesson.color }]}
      >
        <Text style={[styles.heroTitle, lesson.color !== colors.card && styles.heroTitleInverse]}>{lesson.title}</Text>
        <Text style={[styles.heroSubtitle, lesson.color !== colors.card && styles.heroTitleInverse]}>{lesson.chapter}</Text>
      </View>
      <View style={styles.section}>
        <View style={styles.metaRow}>
          <Ionicons name="time-outline" size={s(5)} color={colors.textSecondary} />
          <Text style={styles.metaText}>{lesson.startTime} - {lesson.endTime}</Text>
        </View>
        <View style={styles.metaRow}>
          <Ionicons name="location-outline" size={s(5)} color={colors.textSecondary} />
          <Text style={styles.metaText}>{lesson.room}</Text>
        </View>
        <View style={styles.metaRow}>
          <Ionicons name="person-outline" size={s(5)} color={colors.textSecondary} />
          <Text style={styles.metaText}>{lesson.instructor}</Text>
        </View>
        <Pressable
          onPress={() => navigation.goBack()}
          android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
          style={({ pressed }) => [styles.btn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
        >
          <Text style={styles.btnText}>Back to Schedule</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    padding: s(5),
    gap: s(4),
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  hero: {
    borderRadius: s(5),
    padding: s(5),
  },
  heroTitle: {
    fontSize: s(6),
    fontWeight: '700',
    color: colors.textPrimary,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    lineHeight: s(6) * 1.2,
  },
  heroTitleInverse: {
    color: colors.textInverse,
  },
  heroSubtitle: {
    marginTop: s(2),
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  section: {
    backgroundColor: colors.surface,
    borderRadius: s(5),
    padding: s(5),
    gap: s(3),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 4 },
      default: {},
    }),
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(3),
  },
  metaText: {
    fontSize: s(4),
    fontWeight: '500',
    color: colors.textPrimary,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(4) * 1.4,
  },
  btn: {
    marginTop: s(2),
    backgroundColor: colors.primary,
    borderRadius: s(3),
    paddingVertical: s(3),
    alignItems: 'center',
  },
  btnText: {
    fontSize: s(4),
    fontWeight: '600',
    color: colors.textInverse,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: 0.2,
    lineHeight: s(4) * 1.2,
  },
  title: {
    fontSize: s(5),
    fontWeight: '600',
    color: colors.textPrimary,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: -0.5,
    lineHeight: s(5) * 1.2,
  },
});
