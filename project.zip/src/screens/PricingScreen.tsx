import React, { useState } from 'react';
import { View, FlatList, StyleSheet, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { StatusBar } from 'expo-status-bar';
import { PricingCard } from '../components/PricingCard';
import { SectionHeader } from '../components/SectionHeader';
import { pricingPlans } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function PricingScreen() {
  const [selectedPlanId, setSelectedPlanId] = useState(pricingPlans[1]?.id ?? '');

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={pricingPlans}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <PricingCard plan={item} selected={item.id === selectedPlanId} onSelect={() => setSelectedPlanId(item.id)} />
        )}
        contentContainerStyle={styles.content}
        ListHeaderComponent={
          <Animated.View entering={FadeInUp.duration(400)} style={styles.header}>
            <SectionHeader title="Pricing" subtitle="Flexible plans for startups, scale-ups, and global teams." />
          </Animated.View>
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  content: {
    padding: s(4),
    paddingBottom: s(8),
  },
  header: {
    marginBottom: s(4),
  },
  separator: {
    height: s(4),
  },
});
