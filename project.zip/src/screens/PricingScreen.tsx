import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Platform, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { HeaderBar } from '../components/HeaderBar';
import { PlanCard } from '../components/PlanCard';
import { SegmentedControl } from '../components/SegmentedControl';
import { PrimaryButton } from '../components/PrimaryButton';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { mockPlans } from '../data/mockData';
import { PricingPlan } from '../types';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';
import { useAppContext } from '../../App';

const simulateDelay = async <T,>(value: T, delay = 600) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const pricingRepository = {
  list: async () => mockPlans,
};

const pricingService = {
  list: async () => simulateDelay(await pricingRepository.list()),
};

const usePricing = () => {
  const [plans, setPlans] = useState<PricingPlan[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await pricingService.list();
    setPlans(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { plans, loading };
};

export default function PricingScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'Pricing'>>();
  const { selectedPlanId, setSelectedPlanId } = useAppContext();
  const { plans, loading } = usePricing();
  const [billing, setBilling] = useState('Monthly');

  const savings = (plan: PricingPlan) => Math.max(0, plan.priceMonthly * 12 - plan.priceYearly);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={plans}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          const price = billing === 'Monthly' ? `$${item.priceMonthly}/mo` : `$${item.priceYearly}/yr`;
          const savingText = billing === 'Yearly' ? `Save $${savings(item)} annually` : 'Switch to yearly to save more';
          return (
            <View>
              <PlanCard
                plan={item}
                price={price}
                selected={selectedPlanId === item.id}
                onSelect={() => setSelectedPlanId(item.id)}
              />
              <Text style={styles.savings}>{savingText}</Text>
            </View>
          );
        }}
        style={styles.list}
        ListHeaderComponent={
          <View>
            <HeaderBar title="Pricing plans" subtitle="Pick a plan that scales with your team." />
            <SegmentedControl options={['Monthly', 'Yearly']} value={billing} onChange={setBilling} />
            {loading ? <Text style={styles.loading}>Loading plans...</Text> : null}
          </View>
        }
        ListFooterComponent={
          <PrimaryButton
            label="Confirm selection"
            onPress={() => navigation.navigate('PlanConfirmation')}
            style={styles.confirmButton}
          />
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: s(4),
  },
  loading: {
    marginTop: s(3),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  savings: {
    marginTop: s(1),
    marginBottom: s(3),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  confirmButton: {
    marginTop: s(2),
    marginBottom: s(4),
  },
  separator: {
    height: s(2),
  },
});
