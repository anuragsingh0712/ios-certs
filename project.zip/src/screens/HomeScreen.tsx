import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Platform, ScrollView, FlatList, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { HeaderBar } from '../components/HeaderBar';
import { SectionHeader } from '../components/SectionHeader';
import { KpiCard } from '../components/KpiCard';
import { ActivityRow } from '../components/ActivityRow';
import { EmptyState } from '../components/EmptyState';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { mockActivities, mockKPIs } from '../data/mockData';
import { Activity, KPI } from '../types';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';
import { useAppContext } from '../../App';

const simulateDelay = async <T,>(value: T, delay = 600) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const homeRepository = {
  getHome: async () => ({ kpis: mockKPIs, activities: mockActivities }),
};

const homeService = {
  getHome: async () => {
    if (Math.random() < 0.1) {
      throw new Error('Network error');
    }
    return simulateDelay(await homeRepository.getHome());
  },
};

const useHomeData = () => {
  const [kpis, setKpis] = useState<KPI[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const data = await homeService.getHome();
      setKpis(data.kpis);
      setActivities(data.activities);
      setLoading(false);
    } catch (err) {
      setLoading(false);
      setError(true);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { kpis, activities, loading, error, reload: load };
};

export default function HomeScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'MainTabs'>>();
  const { user } = useAppContext();
  const { kpis, activities, loading, error, reload } = useHomeData();

  const quickActions = [
    { id: 'qa-1', label: 'Pricing', icon: 'pricetag-outline', route: 'Pricing' as const },
    { id: 'qa-2', label: 'Notifications', icon: 'notifications-outline', route: 'Notifications' as const },
    { id: 'qa-3', label: 'Contact', icon: 'chatbubble-ellipses-outline', route: 'Contact' as const },
    { id: 'qa-4', label: 'Testimonials', icon: 'people-outline', route: 'Testimonials' as const },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={activities}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <ActivityRow item={item} />}
        style={styles.list}
        ListHeaderComponent={
          <View>
            <HeaderBar title={`Welcome, ${user.name.split(' ')[0]}`} subtitle="Your SaaS workspace is trending up." />
            <SectionHeader title="Live KPIs" actionLabel="Refresh" onActionPress={reload} />
            <ScrollView
              horizontal
              directionalLockEnabled
              decelerationRate="fast"
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.kpiRow}
            >
              {kpis.map((item) => (
                <KpiCard key={item.id} item={item} />
              ))}
            </ScrollView>
            <SectionHeader title="Quick Actions" />
            <View style={styles.quickGrid}>
              {quickActions.map((action) => (
                <Pressable
                  key={action.id}
                  onPress={() => navigation.navigate(action.route)}
                  android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
                  style={({ pressed }) => [styles.quickCard, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
                >
                  <Ionicons name={action.icon as keyof typeof Ionicons.glyphMap} size={22} color={colors.primary} />
                  <Text style={styles.quickLabel}>{action.label}</Text>
                </Pressable>
              ))}
            </View>
            <SectionHeader title="Recent activity" />
            {loading ? <Text style={styles.loading}>Loading updates...</Text> : null}
            {error ? (
              <EmptyState title="Unable to load" message="We hit a snag loading activity." actionLabel="Retry" onAction={reload} />
            ) : null}
          </View>
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: s(4),
  },
  kpiRow: {
    paddingBottom: s(4),
  },
  quickGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: s(3),
    marginBottom: s(4),
  },
  quickCard: {
    width: '47%',
    padding: s(3),
    borderRadius: s(3),
    backgroundColor: colors.card,
    alignItems: 'center',
    gap: s(2),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  quickLabel: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  loading: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    marginBottom: s(2),
    fontFamily: 'Inter-Medium',
  },
  separator: {
    height: StyleSheet.hairlineWidth,
    backgroundColor: colors.border,
  },
});
