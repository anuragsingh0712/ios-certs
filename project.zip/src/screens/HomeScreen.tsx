import React, { useMemo, useState } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { lessons, subjects } from '../data/mockData';
import { Subject, Lesson } from '../types';
import { SubjectCard } from '../components/SubjectCard';
import { LessonCard } from '../components/LessonCard';
import { HeaderBar } from '../components/HeaderBar';
import { IllustrationCard } from '../components/IllustrationCard';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { RootStackParamList, TabParamList } from '../navigation';

export default function HomeScreen() {
  const navigation = useNavigation<CompositeNavigationProp<
    BottomTabNavigationProp<TabParamList, 'Home'>,
    NativeStackNavigationProp<RootStackParamList>
  >>();
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [subjectList] = useState<Subject[]>(subjects);
  const [lessonList] = useState<Lesson[]>(lessons);

  const filteredLessons = useMemo(() => {
    if (!selectedSubject) return lessonList.slice(0, 3);
    return lessonList.filter((lesson) => lesson.subjectId === selectedSubject).slice(0, 3);
  }, [lessonList, selectedSubject]);

  const handleSubjectPress = (subjectId: string) => {
    setSelectedSubject((prev) => (prev === subjectId ? null : subjectId));
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <FlatList
        data={filteredLessons}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <LessonCard
            lesson={item}
            onPress={() => navigation.navigate('LessonDetail', { id: item.id })}
            onMorePress={() => setSelectedSubject(item.subjectId)}
            compact
          />
        )}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View>
            <View style={styles.hero}>
              <Pressable
                onPress={() => navigation.navigate('Schedule')}
                android_ripple={{ color: 'rgba(0,0,0,0.12)' }}
                style={({ pressed }) => [styles.searchBtn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
              >
                <Ionicons name="search" size={s(5)} color={colors.textInverse} />
              </Pressable>
              <IllustrationCard />
            </View>
            <View style={styles.section}>
              <HeaderBar title="Subjects" subtitle="Recommendations for you" />
              <FlatList
                data={subjectList}
                keyExtractor={(item) => item.id}
                horizontal
                showsHorizontalScrollIndicator={false}
                directionalLockEnabled
                decelerationRate="fast"
                contentContainerStyle={styles.subjectList}
                renderItem={({ item }) => (
                  <SubjectCard subject={item} onPress={() => handleSubjectPress(item.id)} />
                )}
              />
            </View>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Your Schedule</Text>
              <Text style={styles.sectionSubtitle}>Next lessons</Text>
            </View>
          </View>
        }
        ItemSeparatorComponent={() => <View style={{ height: s(3) }} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  listContent: {
    paddingBottom: s(6),
  },
  hero: {
    backgroundColor: colors.primaryDark,
    padding: s(5),
    paddingBottom: s(2),
  },
  searchBtn: {
    width: s(10),
    height: s(10),
    borderRadius: s(4),
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: s(4),
  },
  section: {
    backgroundColor: colors.surface,
    borderTopLeftRadius: s(8),
    borderTopRightRadius: s(8),
    marginTop: s(-4),
    padding: s(5),
    gap: s(4),
  },
  subjectList: {
    paddingTop: s(2),
    paddingBottom: s(2),
  },
  sectionHeader: {
    paddingHorizontal: s(5),
    paddingTop: s(4),
    paddingBottom: s(2),
    backgroundColor: colors.surface,
  },
  sectionTitle: {
    fontSize: s(5),
    fontWeight: '700',
    color: colors.textPrimary,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    lineHeight: s(5) * 1.2,
  },
  sectionSubtitle: {
    marginTop: s(1),
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
});
