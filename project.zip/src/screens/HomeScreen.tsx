import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { DrawerActions, useNavigation } from '@react-navigation/native';
import { DrawerNavigationProp } from '@react-navigation/drawer';
import Animated, { FadeInDown, FadeInUp, SlideInUp } from 'react-native-reanimated';
import { StatusBar } from 'expo-status-bar';
import { HeaderBar } from '../components/HeaderBar';
import { PrimaryButton } from '../components/PrimaryButton';
import { SectionHeader } from '../components/SectionHeader';
import { CollaborationCard } from '../components/CollaborationCard';
import { collaborationItems } from '../data/mockData';
import { RootDrawerParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function HomeScreen() {
  const navigation = useNavigation<DrawerNavigationProp<RootDrawerParamList, 'Home'>>();
  const [selectedId, setSelectedId] = useState(collaborationItems[0]?.id ?? '');

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.content}
        stickyHeaderIndices={[0]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.headerWrap}>
          <HeaderBar title="Circle" onMenuPress={() => navigation.dispatch(DrawerActions.openDrawer())} />
        </View>
        <Animated.View entering={FadeInDown.duration(500)} style={styles.hero}>
          <Text style={styles.heroTitle}>
            A powerful online engagement tool that's intuitive and simple to use.
          </Text>
          <Text style={styles.heroSubtitle}>
            With stellar one-click reports and unmatched support, see how Circle can make a difference in your business.
          </Text>
          <PrimaryButton label="Get Started Free" onPress={() => navigation.navigate('Pricing')} />
        </Animated.View>
        <Animated.View entering={FadeInUp.duration(500)} style={styles.section}>
          <SectionHeader title="Collaboration" subtitle="Modern workflows built for fast-moving teams." />
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            directionalLockEnabled
            decelerationRate="fast"
            contentContainerStyle={styles.horizontalList}
          >
            {collaborationItems.map((item) => (
              <View key={item.id} style={styles.horizontalItem}>
                <CollaborationCard
                  item={item}
                  onPress={() => {
                    setSelectedId(item.id);
                  }}
                />
              </View>
            ))}
          </ScrollView>
          <Text style={styles.selectedText}>
            Selected focus: {collaborationItems.find((item) => item.id === selectedId)?.title}
          </Text>
        </Animated.View>
        <Animated.View entering={SlideInUp.duration(500)} style={styles.section}>
          <SectionHeader title="Premium Insights" subtitle="AI-powered insights with enterprise-grade security." />
          <View style={styles.insightCard}>
            <Text style={styles.insightTitle}>Analytics at scale</Text>
            <Text style={styles.insightBody}>
              Monitor engagement, forecast churn, and activate campaigns with real-time intelligence.
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  scroll: {
    flex: 1,
  },
  content: {
    paddingBottom: s(8),
    gap: s(6),
  },
  headerWrap: {
    backgroundColor: colors.surface,
  },
  hero: {
    paddingHorizontal: s(4),
    gap: s(4),
  },
  heroTitle: {
    fontSize: s(6),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(6) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  heroSubtitle: {
    fontSize: s(3.5),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3.5) * 1.4,
    fontFamily: 'Inter-Medium',
  },
  section: {
    paddingHorizontal: s(4),
    gap: s(3),
  },
  horizontalList: {
    paddingVertical: s(2),
    paddingRight: s(4),
  },
  horizontalItem: {
    marginRight: s(3),
  },
  selectedText: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.primaryDark,
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    fontFamily: 'Inter-SemiBold',
  },
  insightCard: {
    backgroundColor: colors.card,
    borderRadius: s(3),
    padding: s(4),
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: s(1) },
        shadowOpacity: 0.1,
        shadowRadius: s(2),
      },
      android: { elevation: 6 },
      default: {},
    }),
  },
  insightTitle: {
    fontSize: s(4),
    fontWeight: '700',
    color: colors.textPrimary,
    letterSpacing: -0.5,
    lineHeight: s(4) * 1.2,
    fontFamily: 'Inter-Bold',
  },
  insightBody: {
    marginTop: s(2),
    fontSize: s(3.25),
    fontWeight: '500',
    color: colors.textSecondary,
    letterSpacing: 0.2,
    lineHeight: s(3.25) * 1.4,
    fontFamily: 'Inter-Medium',
  },
});
