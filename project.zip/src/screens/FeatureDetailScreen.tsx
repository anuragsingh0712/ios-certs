import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Platform, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRoute, RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { FeatureItem } from '../types';
import { mockFeatures } from '../data/mockData';

const simulateDelay = async <T,>(value: T, delay = 600) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const featureRepository = {
  getById: async (id: string) => mockFeatures.find((item) => item.id === id) || null,
};

const featureService = {
  getById: async (id: string) => simulateDelay(await featureRepository.getById(id)),
};

const useFeatureDetail = (id: string) => {
  const [feature, setFeature] = useState<FeatureItem | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await featureService.getById(id);
    setFeature(data);
    setLoading(false);
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  return { feature, loading };
};

export default function FeatureDetailScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'FeatureDetail'>>();
  const { feature, loading } = useFeatureDetail(route.params.id);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {loading ? <Text style={styles.loading}>Loading feature...</Text> : null}
        {feature ? (
          <View>
            <Text style={styles.title}>{feature.title}</Text>
            <Text style={styles.description}>{feature.description}</Text>
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Benefits</Text>
              {feature.benefits.map((benefit) => (
                <Text key={benefit} style={styles.listItem}>• {benefit}</Text>
              ))}
            </View>
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Insights</Text>
              {feature.insights.map((insight) => (
                <Text key={insight} style={styles.listItem}>• {insight}</Text>
              ))}
            </View>
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Workflows</Text>
              {feature.workflows.map((flow) => (
                <Text key={flow} style={styles.listItem}>• {flow}</Text>
              ))}
            </View>
            <View style={styles.card}>
              <Text style={styles.sectionTitle}>Usage</Text>
              <Text style={styles.usageText}>{feature.usage}% team adoption</Text>
              <View style={styles.progressTrack}>
                <View style={[styles.progressFill, { width: `${feature.usage}%` }]} />
              </View>
            </View>
          </View>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  content: {
    padding: s(4),
  },
  loading: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  title: {
    fontSize: 24,
    lineHeight: 28.8,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  description: {
    marginTop: s(2),
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  card: {
    marginTop: s(4),
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  sectionTitle: {
    fontSize: 16,
    lineHeight: 19.2,
    fontWeight: '600',
    letterSpacing: -0.3,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  listItem: {
    marginTop: s(2),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  usageText: {
    marginTop: s(2),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  progressTrack: {
    marginTop: s(3),
    height: s(1),
    borderRadius: s(1),
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  progressFill: {
    height: s(1),
    borderRadius: s(1),
    backgroundColor: colors.primary,
  },
});
