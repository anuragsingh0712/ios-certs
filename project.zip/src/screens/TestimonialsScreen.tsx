import React, { useRef, useState } from 'react';
import { View, Text, FlatList, StyleSheet, Platform, ViewToken } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, { FadeInUp } from 'react-native-reanimated';
import { StatusBar } from 'expo-status-bar';
import { SectionHeader } from '../components/SectionHeader';
import { TestimonialCard } from '../components/TestimonialCard';
import { testimonials } from '../data/mockData';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function TestimonialsScreen() {
  const [activeIndex, setActiveIndex] = useState(0);
  const viewabilityConfig = useRef({ itemVisiblePercentThreshold: 50 });

  const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    if (viewableItems[0]?.index !== undefined && viewableItems[0]?.index !== null) {
      setActiveIndex(viewableItems[0].index);
    }
  });

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.content}>
        <Animated.View entering={FadeInUp.duration(400)} style={styles.header}>
          <SectionHeader title="Testimonials" subtitle="Trusted by teams that demand clarity, speed, and support." />
        </Animated.View>
        <FlatList
          data={testimonials}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.cardWrap}>
              <TestimonialCard testimonial={item} />
            </View>
          )}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          directionalLockEnabled
          decelerationRate="fast"
          onViewableItemsChanged={onViewableItemsChanged.current}
          viewabilityConfig={viewabilityConfig.current}
          contentContainerStyle={styles.carousel}
          removeClippedSubviews={Platform.OS === 'android'}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={5}
        />
        <View style={styles.pagination}>
          {testimonials.map((item, index) => (
            <View
              key={`dot-${item.id}`}
              style={[styles.dot, index === activeIndex && styles.dotActive]}
            />
          ))}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  content: {
    flex: 1,
    padding: s(4),
    gap: s(4),
  },
  header: {
    marginBottom: s(2),
  },
  carousel: {
    paddingBottom: s(2),
  },
  cardWrap: {
    width: s(72),
    marginRight: s(3),
  },
  pagination: {
    flexDirection: 'row',
    gap: s(1.5),
    justifyContent: 'center',
  },
  dot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    backgroundColor: colors.border,
  },
  dotActive: {
    backgroundColor: colors.accent,
    width: s(4),
  },
});
