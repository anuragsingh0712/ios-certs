import React, { useState } from 'react';
import { View, Text, StyleSheet, Platform, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { HeaderBar } from '../components/HeaderBar';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { mockTestimonials } from '../data/mockData';

export default function TestimonialsScreen() {
  const [index, setIndex] = useState(0);

  const next = () => setIndex((prev) => (prev + 1) % mockTestimonials.length);
  const prev = () => setIndex((prev) => (prev - 1 + mockTestimonials.length) % mockTestimonials.length);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <HeaderBar title="Customer stories" subtitle="Swipe through real-world outcomes." />
        <ScrollView
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          directionalLockEnabled
          decelerationRate="fast"
          onMomentumScrollEnd={(event) => {
            const newIndex = Math.round(event.nativeEvent.contentOffset.x / event.nativeEvent.layoutMeasurement.width);
            setIndex(newIndex);
          }}
        >
          {mockTestimonials.map((item) => (
            <View key={item.id} style={styles.card}>
              <View style={styles.avatar}>
                <Ionicons name="person" size={18} color={colors.textInverse} />
              </View>
              <Text style={styles.review}>{item.review}</Text>
              <Text style={styles.outcome}>{item.outcome}</Text>
              <View style={styles.metaRow}>
                <Text style={styles.name}>{item.name}</Text>
                <Text style={styles.role}>{item.role} · {item.company}</Text>
              </View>
              <Text style={styles.rating}>Rating: {item.rating}/5</Text>
            </View>
          ))}
        </ScrollView>
        <View style={styles.pagination}>
          {mockTestimonials.map((item, idx) => (
            <View key={item.id} style={[styles.dot, idx === index && styles.dotActive]} />
          ))}
        </View>
        <View style={styles.controls}>
          <Pressable
            onPress={prev}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.controlBtn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
          >
            <Text style={styles.controlText}>Previous</Text>
          </Pressable>
          <Pressable
            onPress={next}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.controlBtn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
          >
            <Text style={styles.controlText}>Next</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  content: {
    padding: s(4),
  },
  card: {
    width: s(68),
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginRight: s(3),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  avatar: {
    width: s(8),
    height: s(8),
    borderRadius: s(4),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  review: {
    marginTop: s(3),
    fontSize: 16,
    lineHeight: 19.2,
    fontWeight: '600',
    letterSpacing: -0.3,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  outcome: {
    marginTop: s(2),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  metaRow: {
    marginTop: s(4),
  },
  name: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  role: {
    marginTop: s(1),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  rating: {
    marginTop: s(3),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.success,
    fontFamily: 'Inter-Medium',
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: s(3),
    gap: s(2),
  },
  dot: {
    width: s(2),
    height: s(2),
    borderRadius: s(1),
    backgroundColor: colors.border,
  },
  dotActive: {
    backgroundColor: colors.primary,
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: s(4),
    gap: s(3),
  },
  controlBtn: {
    flex: 1,
    paddingVertical: s(3),
    alignItems: 'center',
    borderRadius: s(2),
    backgroundColor: colors.surface,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  controlText: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
});
