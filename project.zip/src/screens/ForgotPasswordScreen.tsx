import React, { useState } from 'react';
import { View, Text, StyleSheet, Platform, KeyboardAvoidingView, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { PrimaryButton } from '../components/PrimaryButton';
import { TextField } from '../components/TextField';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

const simulateDelay = async <T,>(value: T, delay = 700) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const recoveryRepository = {
  requestReset: async (email: string) => {
    if (!email.includes('@')) {
      throw new Error('Invalid email');
    }
    return { ok: true };
  },
};

const recoveryService = {
  requestReset: async (email: string) => {
    const result = await recoveryRepository.requestReset(email);
    return simulateDelay(result);
  },
};

export default function ForgotPasswordScreen() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const handleSubmit = async () => {
    setStatus('loading');
    setMessage('');
    try {
      await recoveryService.requestReset(email);
      setStatus('success');
      setMessage('Reset link sent. Please check your inbox.');
    } catch (err) {
      setStatus('error');
      setMessage('Please enter a valid email address.');
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.header}>
            <Text style={styles.title}>Reset your password</Text>
            <Text style={styles.subtitle}>We will send a secure reset link to your email.</Text>
          </View>
          <TextField label="Email" value={email} onChangeText={setEmail} placeholder="name@company.com" keyboardType="email-address" />
          {message ? (
            <Text style={[styles.message, status === 'error' && styles.error]}>{message}</Text>
          ) : null}
          <PrimaryButton label={status === 'loading' ? 'Sending...' : 'Send Reset Link'} onPress={handleSubmit} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  flex: {
    flex: 1,
  },
  scrollContent: {
    padding: s(4),
  },
  header: {
    marginBottom: s(5),
  },
  title: {
    fontSize: 24,
    lineHeight: 28.8,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  subtitle: {
    marginTop: s(2),
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  message: {
    marginBottom: s(3),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.success,
    fontFamily: 'Inter-Medium',
  },
  error: {
    color: colors.error,
  },
});
