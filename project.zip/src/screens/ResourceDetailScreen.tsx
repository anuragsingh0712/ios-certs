import React, { useCallback, useEffect, useState } from 'react';
import { View, Text, StyleSheet, Platform, ScrollView, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { useRoute, RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../navigation';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { ResourceItem } from '../types';
import { mockResources } from '../data/mockData';
import { useAppContext } from '../../App';

const simulateDelay = async <T,>(value: T, delay = 600) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const resourceRepository = {
  getById: async (id: string) => mockResources.find((item) => item.id === id) || null,
};

const resourceService = {
  getById: async (id: string) => simulateDelay(await resourceRepository.getById(id)),
};

const useResourceDetail = (id: string) => {
  const [resource, setResource] = useState<ResourceItem | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await resourceService.getById(id);
    setResource(data);
    setLoading(false);
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  return { resource, loading };
};

export default function ResourceDetailScreen() {
  const route = useRoute<RouteProp<RootStackParamList, 'ResourceDetail'>>();
  const { resource, loading } = useResourceDetail(route.params.id);
  const { bookmarks, toggleBookmark } = useAppContext();

  if (!resource) {
    return (
      <SafeAreaView style={styles.safe}>
        <StatusBar style="dark" />
        <View style={styles.container}>
          <Text style={styles.loading}>{loading ? 'Loading resource...' : 'Resource not found.'}</Text>
        </View>
      </SafeAreaView>
    );
  }

  const bookmarked = bookmarks.includes(resource.id);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.category}>{resource.category}</Text>
        <Text style={styles.title}>{resource.title}</Text>
        <Text style={styles.summary}>{resource.summary}</Text>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Overview</Text>
          <Text style={styles.body}>{resource.content}</Text>
        </View>
        <Pressable
          onPress={() => toggleBookmark(resource.id)}
          android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
          style={({ pressed }) => [styles.bookmarkBtn, pressed && Platform.OS === 'ios' && { opacity: 0.8 }]}
        >
          <Text style={styles.bookmarkText}>{bookmarked ? 'Remove bookmark' : 'Save bookmark'}</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  container: {
    flex: 1,
    padding: s(4),
  },
  content: {
    padding: s(4),
  },
  loading: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  category: {
    fontSize: 11,
    lineHeight: 15.4,
    fontWeight: '600',
    letterSpacing: 1.2,
    color: colors.primary,
    textTransform: 'uppercase',
    fontFamily: 'Inter-SemiBold',
  },
  title: {
    marginTop: s(2),
    fontSize: 24,
    lineHeight: 28.8,
    fontWeight: '700',
    letterSpacing: -0.5,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  summary: {
    marginTop: s(2),
    fontSize: 14,
    lineHeight: 19.6,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  card: {
    marginTop: s(4),
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  sectionTitle: {
    fontSize: 16,
    lineHeight: 19.2,
    fontWeight: '600',
    letterSpacing: -0.3,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  body: {
    marginTop: s(2),
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  bookmarkBtn: {
    marginTop: s(4),
    paddingVertical: s(3),
    alignItems: 'center',
    borderRadius: s(2),
    backgroundColor: colors.primary,
  },
  bookmarkText: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textInverse,
    fontFamily: 'Inter-SemiBold',
  },
});
