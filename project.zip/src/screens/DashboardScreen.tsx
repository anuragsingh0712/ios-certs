import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Platform, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { HeaderBar } from '../components/HeaderBar';
import { SegmentedControl } from '../components/SegmentedControl';
import { EmptyState } from '../components/EmptyState';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { mockKPIs } from '../data/mockData';
import { KPI } from '../types';

const simulateDelay = async <T,>(value: T, delay = 600) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const dashboardRepository = {
  getMetrics: async () => mockKPIs,
};

const dashboardService = {
  getMetrics: async () => simulateDelay(await dashboardRepository.getMetrics()),
};

const useDashboardData = () => {
  const [metrics, setMetrics] = useState<KPI[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(false);
    try {
      const data = await dashboardService.getMetrics();
      setMetrics(data);
      setLoading(false);
    } catch (err) {
      setError(true);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { metrics, loading, error, reload: load };
};

export default function DashboardScreen() {
  const { metrics, loading, error, reload } = useDashboardData();
  const [filter, setFilter] = useState('Weekly');

  const filtered = useMemo(() => {
    if (filter === 'Daily') {
      return metrics.map((metric) => ({ ...metric, value: metric.value, delta: '+2%' }));
    }
    if (filter === 'Monthly') {
      return metrics.map((metric) => ({ ...metric, value: metric.value, delta: '+12%' }));
    }
    return metrics;
  }, [metrics, filter]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          const progress = Math.min(100, Math.max(20, parseInt(item.value.replace(/[^0-9]/g, ''), 10) % 100));
          const toneColor = item.tone === 'success' ? colors.success : item.tone === 'warning' ? colors.warning : colors.info;
          return (
            <View style={styles.metricCard}>
              <View style={styles.metricRow}>
                <Text style={styles.metricLabel}>{item.label}</Text>
                <Text style={[styles.metricDelta, { color: toneColor }]}>{item.delta}</Text>
              </View>
              <Text style={styles.metricValue}>{item.value}</Text>
              <View style={styles.progressTrack}>
                <View style={[styles.progressFill, { width: `${progress}%`, backgroundColor: toneColor }]} />
              </View>
            </View>
          );
        }}
        style={styles.list}
        ListHeaderComponent={
          <View>
            <HeaderBar title="Performance dashboard" subtitle="Track key trends in one glance." />
            <SegmentedControl options={['Daily', 'Weekly', 'Monthly']} value={filter} onChange={setFilter} />
            {loading ? <Text style={styles.loading}>Refreshing analytics...</Text> : null}
            {error ? (
              <EmptyState title="Dashboard unavailable" message="We could not refresh insights." actionLabel="Try again" onAction={reload} />
            ) : null}
          </View>
        }
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: s(4),
  },
  metricCard: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  metricRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metricLabel: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-SemiBold',
  },
  metricDelta: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    fontFamily: 'Inter-SemiBold',
  },
  metricValue: {
    marginTop: s(2),
    fontSize: 22,
    lineHeight: 26.4,
    fontWeight: '700',
    letterSpacing: -0.4,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  progressTrack: {
    marginTop: s(3),
    height: s(1),
    borderRadius: s(1),
    backgroundColor: colors.border,
    overflow: 'hidden',
  },
  progressFill: {
    height: s(1),
    borderRadius: s(1),
  },
  loading: {
    marginTop: s(3),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  separator: {
    height: s(3),
  },
});
