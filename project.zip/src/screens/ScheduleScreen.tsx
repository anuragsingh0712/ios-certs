import React, { useMemo, useState } from 'react';
import { View, Text, FlatList, Pressable, StyleSheet, Platform, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { lessons } from '../data/mockData';
import { Lesson } from '../types';
import { DayChip } from '../components/DayChip';
import { LessonCard } from '../components/LessonCard';
import { TimeSlotRow } from '../components/TimeSlotRow';
import { CompositeNavigationProp, useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import { RootStackParamList, TabParamList } from '../navigation';

const weekDays = [
  { key: 'Sun', label: 'S', date: '21' },
  { key: 'Mon', label: 'M', date: '22' },
  { key: 'Tue', label: 'T', date: '23' },
  { key: 'Wed', label: 'W', date: '24' },
  { key: 'Thu', label: 'T', date: '25' },
  { key: 'Fri', label: 'F', date: '26' },
  { key: 'Sat', label: 'S', date: '27' },
];

const weekdayMap = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function ScheduleScreen() {
  const navigation = useNavigation<CompositeNavigationProp<
    BottomTabNavigationProp<TabParamList, 'Schedule'>,
    NativeStackNavigationProp<RootStackParamList>
  >>();
  const today = new Date();
  const todayKey = weekdayMap[today.getDay()];
  const [selectedDay, setSelectedDay] = useState<string>(todayKey);
  const [lessonList, setLessonList] = useState<Lesson[]>(lessons);
  const dateNumber = today.getDate();
  const dateMonth = `${today.toLocaleString('en-US', { month: 'short' })} ${today.getFullYear()}`;
  const dateDay = todayKey;

  const filteredLessons = useMemo(() => {
    return lessonList.filter((lesson) => lesson.day === selectedDay);
  }, [lessonList, selectedDay]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={filteredLessons}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TimeSlotRow startTime={item.startTime} endTime={item.endTime}>
            <LessonCard
              lesson={item}
              onPress={() => navigation.navigate('LessonDetail', { id: item.id })}
              onMorePress={() => setLessonList((prev) => prev.filter((lesson) => lesson.id !== item.id))}
            />
          </TimeSlotRow>
        )}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View style={styles.header}>
            <View style={styles.dateRow}>
              <View>
                <Text style={styles.dateNumber}>{dateNumber}</Text>
              </View>
              <View style={styles.dateInfo}>
                <Text style={styles.dateDay}>{dateDay}</Text>
                <Text style={styles.dateMonth}>{dateMonth}</Text>
              </View>
              <View style={styles.spacer} />
              <View style={styles.todayBadge}>
                <Text style={styles.todayText}>Today</Text>
              </View>
            </View>
            <ScrollView
              horizontal
              directionalLockEnabled
              decelerationRate="fast"
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.dayRow}
            >
              {weekDays.map((day) => (
                <DayChip
                  key={day.key}
                  label={day.label}
                  date={day.date}
                  active={selectedDay === day.key}
                  onPress={() => setSelectedDay(day.key)}
                />
              ))}
            </ScrollView>
            <View style={styles.tableHeader}>
              <Text style={styles.tableHeaderText}>Time</Text>
              <Text style={styles.tableHeaderText}>Course</Text>
              <Pressable
                onPress={() => setSelectedDay(todayKey)}
                android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
                style={({ pressed }) => [styles.filterBtn, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
              >
                <Ionicons name="filter" size={s(4)} color={colors.textSecondary} />
              </Pressable>
            </View>
          </View>
        }
        ItemSeparatorComponent={() => <View style={{ height: s(4) }} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  listContent: {
    padding: s(5),
    gap: s(3),
  },
  header: {
    gap: s(4),
  },
  dateRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dateNumber: {
    fontSize: s(8),
    fontWeight: '700',
    color: colors.textPrimary,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    lineHeight: s(8) * 1.1,
  },
  dateInfo: {
    marginLeft: s(3),
  },
  dateDay: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.textSecondary,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  dateMonth: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textDisabled,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  spacer: {
    flex: 1,
  },
  todayBadge: {
    paddingHorizontal: s(4),
    paddingVertical: s(2),
    borderRadius: s(3),
    backgroundColor: colors.primaryLight,
  },
  todayText: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.success,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.2,
  },
  dayRow: {
    gap: s(2),
  },
  tableHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(3),
  },
  tableHeaderText: {
    fontSize: s(3),
    fontWeight: '600',
    color: colors.textDisabled,
    fontFamily: 'Poppins-SemiBold',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
  },
  filterBtn: {
    marginLeft: 'auto',
    width: s(8),
    height: s(8),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: s(4),
  },
});
