import React from 'react';
import { View, Text, StyleSheet, Platform, Pressable, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { HeaderBar } from '../components/HeaderBar';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { useAppContext } from '../../App';
import { mockPlans } from '../data/mockData';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';

export default function ProfileScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'MainTabs'>>();
  const { user, selectedPlanId, theme, toggleTheme, notificationsEnabled, toggleNotifications, clearLocalData, setSession } = useAppContext();
  const plan = mockPlans.find((item) => item.id === selectedPlanId) || mockPlans[0];

  const actions = [
    { id: 'act-1', label: 'Edit profile', icon: 'create-outline', route: 'EditProfile' as const },
    { id: 'act-2', label: 'Pricing', icon: 'pricetag-outline', route: 'Pricing' as const },
    { id: 'act-3', label: 'Notifications', icon: 'notifications-outline', route: 'Notifications' as const },
    { id: 'act-4', label: 'Contact support', icon: 'chatbubble-ellipses-outline', route: 'Contact' as const },
    { id: 'act-5', label: 'Testimonials', icon: 'people-outline', route: 'Testimonials' as const },
  ];

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <HeaderBar title="Profile" subtitle="Manage your SaaS workspace." />
        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <Ionicons name="person" size={20} color={colors.textInverse} />
          </View>
          <View style={styles.profileInfo}>
            <Text style={styles.name}>{user.name}</Text>
            <Text style={styles.email}>{user.email}</Text>
            <Text style={styles.role}>{user.role} · {user.company}</Text>
          </View>
        </View>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Current plan</Text>
          <Text style={styles.planName}>{plan.name}</Text>
          <Text style={styles.planDescription}>{plan.description}</Text>
        </View>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Preferences</Text>
          <Pressable
            onPress={toggleNotifications}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.settingRow, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
          >
            <Text style={styles.settingLabel}>Notifications</Text>
            <Text style={styles.settingValue}>{notificationsEnabled ? 'Enabled' : 'Muted'}</Text>
          </Pressable>
          <Pressable
            onPress={toggleTheme}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.settingRow, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
          >
            <Text style={styles.settingLabel}>Theme</Text>
            <Text style={styles.settingValue}>{theme === 'light' ? 'Light' : 'Dark'}</Text>
          </Pressable>
        </View>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Actions</Text>
          {actions.map((action) => (
            <Pressable
              key={action.id}
              onPress={() => navigation.navigate(action.route)}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.actionRow, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
            >
              <View style={styles.actionLabelRow}>
                <Ionicons name={action.icon as keyof typeof Ionicons.glyphMap} size={18} color={colors.primary} />
                <Text style={styles.actionLabel}>{action.label}</Text>
              </View>
              <Ionicons name="chevron-forward" size={16} color={colors.textDisabled} />
            </Pressable>
          ))}
        </View>
        <View style={styles.card}>
          <Pressable
            onPress={clearLocalData}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.actionRow, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
          >
            <Text style={styles.actionLabel}>Clear local data</Text>
          </Pressable>
          <Pressable
            onPress={() => {
              setSession(false);
              navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
            }}
            android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
            style={({ pressed }) => [styles.actionRow, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
          >
            <Text style={styles.logout}>Log out</Text>
          </Pressable>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  content: {
    padding: s(4),
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginBottom: s(4),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  avatar: {
    width: s(10),
    height: s(10),
    borderRadius: s(5),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: s(3),
  },
  profileInfo: {
    flex: 1,
  },
  name: {
    fontSize: 18,
    lineHeight: 21.6,
    fontWeight: '700',
    letterSpacing: -0.4,
    color: colors.textPrimary,
    fontFamily: 'Inter-Bold',
  },
  email: {
    marginTop: s(1),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  role: {
    marginTop: s(1),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textDisabled,
    fontFamily: 'Inter-Medium',
  },
  card: {
    padding: s(4),
    borderRadius: s(3),
    backgroundColor: colors.card,
    marginBottom: s(4),
    ...Platform.select({
      ios: {
        shadowColor: colors.shadowColor,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.08,
        shadowRadius: 6,
      },
      android: { elevation: 3 },
      default: {},
    }),
  },
  sectionTitle: {
    fontSize: 16,
    lineHeight: 19.2,
    fontWeight: '600',
    letterSpacing: -0.3,
    color: colors.textPrimary,
    marginBottom: s(3),
    fontFamily: 'Inter-SemiBold',
  },
  planName: {
    fontSize: 15,
    lineHeight: 18,
    fontWeight: '600',
    letterSpacing: -0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-SemiBold',
  },
  planDescription: {
    marginTop: s(2),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '400',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Regular',
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: s(2),
  },
  settingLabel: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-Medium',
  },
  settingValue: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  actionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: s(3),
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  actionLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: s(2),
  },
  actionLabel: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textPrimary,
    fontFamily: 'Inter-Medium',
  },
  logout: {
    fontSize: 13,
    lineHeight: 18.2,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.error,
    fontFamily: 'Inter-SemiBold',
  },
});
