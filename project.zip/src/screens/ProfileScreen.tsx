import React from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';

export default function ProfileScreen() {
  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.container}>
        <View style={styles.avatar}>
          <Ionicons name="person" size={s(6)} color={colors.textInverse} />
        </View>
        <Text style={styles.title}>Student Profile</Text>
        <Text style={styles.subtitle}>Manage your account and preferences.</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: s(5),
    gap: s(2),
  },
  avatar: {
    width: s(12),
    height: s(12),
    borderRadius: s(6),
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: s(6),
    fontWeight: '700',
    color: colors.textPrimary,
    fontFamily: 'Poppins-Bold',
    letterSpacing: -0.5,
    lineHeight: s(6) * 1.2,
  },
  subtitle: {
    fontSize: s(3),
    fontWeight: '500',
    color: colors.textSecondary,
    fontFamily: 'Poppins-Medium',
    letterSpacing: 0.2,
    lineHeight: s(3) * 1.4,
    textAlign: 'center',
  },
});
