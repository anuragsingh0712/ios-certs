import React, { useMemo } from 'react';
import { View, Text, StyleSheet, Platform, FlatList, Pressable } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { HeaderBar } from '../components/HeaderBar';
import { NotificationRow } from '../components/NotificationRow';
import { EmptyState } from '../components/EmptyState';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { useAppContext } from '../../App';

export default function NotificationsScreen() {
  const { notifications, markAllRead, toggleNotificationRead, dismissNotification } = useAppContext();
  const unreadCount = useMemo(() => notifications.filter((item) => !item.read).length, [notifications]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <NotificationRow
            item={item}
            onToggleRead={() => toggleNotificationRead(item.id)}
            onDismiss={() => dismissNotification(item.id)}
          />
        )}
        style={styles.list}
        ListHeaderComponent={
          <View>
            <HeaderBar title="Notification center" subtitle={`${unreadCount} unread alerts`} />
            <Pressable
              onPress={markAllRead}
              android_ripple={{ color: 'rgba(0,0,0,0.08)' }}
              style={({ pressed }) => [styles.markAll, pressed && Platform.OS === 'ios' && { opacity: 0.7 }]}
            >
              <Text style={styles.markAllText}>Mark all as read</Text>
            </Pressable>
            {notifications.length === 0 ? (
              <EmptyState title="All caught up" message="No notifications right now." />
            ) : null}
          </View>
        }
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: s(4),
  },
  markAll: {
    alignSelf: 'flex-start',
    paddingHorizontal: s(3),
    paddingVertical: s(2),
    borderRadius: s(2),
    backgroundColor: colors.primaryLight,
    marginBottom: s(3),
  },
  markAllText: {
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '600',
    letterSpacing: 0.2,
    color: colors.primary,
    fontFamily: 'Inter-SemiBold',
  },
  separator: {
    height: s(1),
  },
});
