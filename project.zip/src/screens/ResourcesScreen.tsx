import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Platform, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { HeaderBar } from '../components/HeaderBar';
import { ResourceCard } from '../components/ResourceCard';
import { SegmentedControl } from '../components/SegmentedControl';
import { EmptyState } from '../components/EmptyState';
import { TextField } from '../components/TextField';
import { colors } from '../theme/colors';
import { s } from '../theme/spacing';
import { mockResources } from '../data/mockData';
import { ResourceItem } from '../types';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation';
import { useAppContext } from '../../App';

const simulateDelay = async <T,>(value: T, delay = 600) =>
  new Promise<T>((resolve) => {
    setTimeout(() => resolve(value), delay);
  });

const resourceRepository = {
  list: async () => mockResources,
};

const resourceService = {
  list: async () => simulateDelay(await resourceRepository.list()),
};

const useResources = () => {
  const [items, setItems] = useState<ResourceItem[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const data = await resourceService.list();
    setItems(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { items, loading };
};

export default function ResourcesScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList, 'MainTabs'>>();
  const { bookmarks } = useAppContext();
  const { items, loading } = useResources();
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    return items.filter((item) => {
      const matchesCategory = category === 'All' || item.category === category;
      const matchesSearch = item.title.toLowerCase().includes(search.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [items, category, search]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ResourceCard
            item={item}
            bookmarked={bookmarks.includes(item.id)}
            onPress={() => navigation.navigate('ResourceDetail', { id: item.id })}
          />
        )}
        style={styles.list}
        ListHeaderComponent={
          <View>
            <HeaderBar title="Resources" subtitle="Guides and playbooks for your team." />
            <TextField label="Search" value={search} onChangeText={setSearch} placeholder="Search articles" />
            <SegmentedControl options={['All', 'Article', 'Tutorial', 'FAQ', 'Guide']} value={category} onChange={setCategory} />
            {loading ? <Text style={styles.loading}>Loading library...</Text> : null}
            {!loading && filtered.length === 0 ? (
              <EmptyState title="No results" message="Try adjusting filters or keywords." />
            ) : null}
          </View>
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        removeClippedSubviews={Platform.OS === 'android'}
        initialNumToRender={10}
        maxToRenderPerBatch={10}
        windowSize={5}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: colors.background,
    ...(Platform.OS === 'web' ? { overflow: 'hidden' as any, maxHeight: '100vh' as any } : {}),
  },
  list: {
    flex: 1,
  },
  listContent: {
    padding: s(4),
  },
  loading: {
    marginTop: s(3),
    fontSize: 12,
    lineHeight: 16.8,
    fontWeight: '500',
    letterSpacing: 0.2,
    color: colors.textSecondary,
    fontFamily: 'Inter-Medium',
  },
  separator: {
    height: s(2),
  },
});
