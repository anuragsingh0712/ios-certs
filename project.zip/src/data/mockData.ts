import { Activity, ContactSubmission, FeatureItem, KPI, NotificationItem, PricingPlan, ResourceItem, Testimonial, User } from '../types';

export const mockUser: User = {
  id: 'user-1',
  name: 'Avery Chen',
  email: 'avery@saasify.io',
  company: 'SaaSify Labs',
  role: 'Product Lead',
};

export const mockKPIs: KPI[] = [
  { id: 'kpi-1', label: 'Customers', value: '1,284', trend: 'up', delta: '+12%', tone: 'success' },
  { id: 'kpi-2', label: 'Revenue', value: '$92.4k', trend: 'up', delta: '+8%', tone: 'success' },
  { id: 'kpi-3', label: 'Projects', value: '86', trend: 'up', delta: '+5%', tone: 'info' },
  { id: 'kpi-4', label: 'Engagement', value: '74%', trend: 'down', delta: '-3%', tone: 'warning' },
  { id: 'kpi-5', label: 'Uptime', value: '99.9%', trend: 'up', delta: '+0.2%', tone: 'success' },
];

export const mockActivities: Activity[] = [
  { id: 'act-1', title: 'New enterprise signup', subtitle: 'Vertex Corp', time: '2m ago', tone: 'success' },
  { id: 'act-2', title: 'Weekly usage report', subtitle: 'Engagement up 6%', time: '1h ago', tone: 'info' },
  { id: 'act-3', title: 'Automation flow updated', subtitle: 'Renewal reminders', time: '3h ago', tone: 'info' },
  { id: 'act-4', title: 'Churn risk detected', subtitle: '3 accounts flagged', time: '5h ago', tone: 'warning' },
  { id: 'act-5', title: 'Pipeline sync complete', subtitle: 'Salesforce integration', time: '8h ago', tone: 'success' },
  { id: 'act-6', title: 'Q3 roadmap published', subtitle: '6 initiatives added', time: '1d ago', tone: 'info' },
  { id: 'act-7', title: 'Security scan clean', subtitle: 'No issues found', time: '2d ago', tone: 'success' },
  { id: 'act-8', title: 'Reminder sent', subtitle: 'Upcoming renewal', time: '3d ago', tone: 'warning' },
];

export const mockFeatures: FeatureItem[] = [
  {
    id: 'feat-1',
    title: 'Analytics Suite',
    summary: 'Track product health with live metrics.',
    description: 'Unified analytics with cohort tracking, retention curves, and revenue attribution.',
    benefits: ['Cohort analysis', 'Revenue attribution', 'Live KPIs'],
    insights: ['Power users retain 3.2x', 'Automation boosts LTV by 14%'],
    workflows: ['Connect data sources', 'Build dashboards', 'Share insights'],
    usage: 78,
  },
  {
    id: 'feat-2',
    title: 'Automation Hub',
    summary: 'Design workflows that run themselves.',
    description: 'Drag-and-drop automations with approval routing and escalation rules.',
    benefits: ['Smart routing', 'SLA tracking', 'Conditional steps'],
    insights: ['Saved 126 hours last month', '92% tasks auto-resolved'],
    workflows: ['Choose trigger', 'Configure rules', 'Monitor results'],
    usage: 64,
  },
  {
    id: 'feat-3',
    title: 'Collaboration',
    summary: 'Keep every team aligned in real time.',
    description: 'Shared workspaces, live comments, and project health status in one view.',
    benefits: ['Shared inbox', 'Live comments', 'Team OKRs'],
    insights: ['Cross-team response +22%', '40% faster launches'],
    workflows: ['Invite team', 'Assign owners', 'Track progress'],
    usage: 88,
  },
];

export const mockPlans: PricingPlan[] = [
  {
    id: 'plan-1',
    name: 'Starter',
    priceMonthly: 29,
    priceYearly: 290,
    description: 'For emerging teams getting traction.',
    features: ['Core analytics', '3 projects', 'Email support'],
    highlighted: false,
  },
  {
    id: 'plan-2',
    name: 'Professional',
    priceMonthly: 79,
    priceYearly: 790,
    description: 'For scaling teams that need automation.',
    features: ['Automation hub', 'Unlimited projects', 'Priority support'],
    highlighted: true,
  },
  {
    id: 'plan-3',
    name: 'Enterprise',
    priceMonthly: 149,
    priceYearly: 1490,
    description: 'For global orgs with advanced security.',
    features: ['SSO & SCIM', 'Dedicated success', 'Custom analytics'],
    highlighted: false,
  },
];

export const mockResources: ResourceItem[] = [
  {
    id: 'res-1',
    title: 'Launching a KPI dashboard',
    category: 'Guide',
    summary: 'Structure KPIs for fast decision making.',
    content: 'Define north-star metrics, align dashboards with teams, and review weekly.',
    duration: '6 min read',
  },
  {
    id: 'res-2',
    title: 'Automation playbook',
    category: 'Article',
    summary: 'High-impact workflows for SaaS ops.',
    content: 'Start with onboarding, renewals, and escalations to save time.',
    duration: '4 min read',
  },
  {
    id: 'res-3',
    title: 'Collaboration templates',
    category: 'Tutorial',
    summary: 'Reusable project briefs and rituals.',
    content: 'Use weekly updates, launch checklists, and daily standups.',
    duration: '8 min read',
  },
  {
    id: 'res-4',
    title: 'Security overview',
    category: 'FAQ',
    summary: 'How we protect enterprise data.',
    content: 'Encryption at rest, least-privilege access, and audit logs.',
    duration: '3 min read',
  },
  {
    id: 'res-5',
    title: 'Customer success guide',
    category: 'Guide',
    summary: 'Drive renewals with health scores.',
    content: 'Monitor adoption, respond to risk, and highlight outcomes.',
    duration: '7 min read',
  },
  {
    id: 'res-6',
    title: 'Integration checklist',
    category: 'Article',
    summary: 'Connect data sources quickly.',
    content: 'Prioritize CRM, billing, and product analytics to power insights.',
    duration: '5 min read',
  },
  {
    id: 'res-7',
    title: 'Usage analytics 101',
    category: 'Tutorial',
    summary: 'Make sense of daily active users.',
    content: 'Combine cohorts with funnels to understand activation.',
    duration: '9 min read',
  },
  {
    id: 'res-8',
    title: 'Pricing strategy FAQ',
    category: 'FAQ',
    summary: 'Common questions about plan design.',
    content: 'Bundle features to align value with customer outcomes.',
    duration: '4 min read',
  },
];

export const mockNotifications: NotificationItem[] = [
  { id: 'note-1', title: 'New renewal alert', body: 'Metroline renews in 14 days.', time: '10m ago', read: false },
  { id: 'note-2', title: 'Usage spike', body: 'Engagement up 12% today.', time: '1h ago', read: false },
  { id: 'note-3', title: 'Billing sync', body: 'Stripe payouts reconciled.', time: '3h ago', read: true },
  { id: 'note-4', title: 'Workflow paused', body: 'Approval required for 2 tasks.', time: '5h ago', read: false },
  { id: 'note-5', title: 'New comment', body: 'Design review updated.', time: '1d ago', read: true },
  { id: 'note-6', title: 'Security update', body: 'All scans passed.', time: '2d ago', read: true },
  { id: 'note-7', title: 'Reminder', body: 'Quarterly plan review tomorrow.', time: '3d ago', read: false },
  { id: 'note-8', title: 'Integration complete', body: 'HubSpot sync activated.', time: '4d ago', read: true },
];

export const mockTestimonials: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Maya Singh',
    role: 'VP Operations',
    company: 'Northwind',
    review: 'We reduced manual reporting by 40% in the first month.',
    rating: 5,
    outcome: 'Automations scaled the CS team without new headcount.',
  },
  {
    id: 'test-2',
    name: 'Oliver Reed',
    role: 'Head of Growth',
    company: 'Nimbus',
    review: 'The analytics suite made our board decks effortless.',
    rating: 5,
    outcome: 'Weekly KPIs are now ready in minutes.',
  },
  {
    id: 'test-3',
    name: 'Sofia Martinez',
    role: 'Product Lead',
    company: 'Lumen',
    review: 'Collaboration features kept every launch on track.',
    rating: 4,
    outcome: 'Launch readiness improved by 28%.',
  },
  {
    id: 'test-4',
    name: 'Ethan Park',
    role: 'RevOps Manager',
    company: 'Aether',
    review: 'Pricing insights helped us right-size enterprise deals.',
    rating: 5,
    outcome: 'Revenue per account up 11%.',
  },
  {
    id: 'test-5',
    name: 'Isla Patel',
    role: 'Customer Success',
    company: 'Quill',
    review: 'Notification center keeps us ahead of churn risks.',
    rating: 4,
    outcome: 'Renewals stabilized across top accounts.',
  },
];

export const mockContactSubmissions: ContactSubmission[] = [
  {
    id: 'contact-1',
    name: 'Jules Avery',
    email: 'jules@vector.com',
    company: 'Vector',
    message: 'Interested in enterprise automation flows.',
    createdAt: '2024-05-12T10:00:00Z',
    status: 'success',
  },
  {
    id: 'contact-2',
    name: 'Riley Morgan',
    email: 'riley@halcyon.io',
    company: 'Halcyon',
    message: 'Need onboarding guidance for a 20-person team.',
    createdAt: '2024-05-19T14:30:00Z',
    status: 'success',
  },
];
