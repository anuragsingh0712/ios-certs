import { CollaborationItem, CompanyValue, Feature, PricingPlan, ResourceItem, Testimonial } from '../types';

export const collaborationItems: CollaborationItem[] = [
  { id: 'c1', title: 'Unified Dashboards', subtitle: 'Real-time engagement insights' },
  { id: 'c2', title: 'Team Workspaces', subtitle: 'Shared notes and approvals' },
  { id: 'c3', title: 'Automation Cards', subtitle: 'Trigger-based workflows' },
  { id: 'c4', title: 'Customer Pulse', subtitle: 'Sentiment tracking' },
  { id: 'c5', title: 'Launch Studio', subtitle: 'Campaign playbooks' },
];

export const features: Feature[] = [
  {
    id: 'f1',
    title: 'Analytics',
    description: 'Reporting and engagement metrics in one secure command center.',
    icon: 'analytics',
    highlight: '98% reporting accuracy',
  },
  {
    id: 'f2',
    title: 'Community',
    description: 'Stronger customer relationships with smart outreach and feedback loops.',
    icon: 'people',
    highlight: '3x retention uplift',
  },
  {
    id: 'f3',
    title: 'Automation',
    description: 'Workflow automation that keeps every signal routed and actioned.',
    icon: 'autorenew',
    highlight: '24/7 orchestration',
  },
];

export const testimonials: Testimonial[] = [
  {
    id: 't1',
    name: 'Avery Chen',
    company: 'Northwind Capital',
    review: 'Circle replaced four dashboards and gave us clarity in a single view. The onboarding was instant.',
    rating: 5,
  },
  {
    id: 't2',
    name: 'Maya Patel',
    company: 'Brightline AI',
    review: 'The automation workflows are the fastest we have tested. We hit insights the same day.',
    rating: 5,
  },
  {
    id: 't3',
    name: 'Liam Brooks',
    company: 'Vertex Labs',
    review: 'The data story is obvious. Every stakeholder sees the same truth and makes faster decisions.',
    rating: 4,
  },
  {
    id: 't4',
    name: 'Elena Rossi',
    company: 'Arcadia Systems',
    review: 'Circle feels enterprise-ready and premium. Our teams love the polished mobile experience.',
    rating: 5,
  },
];

export const pricingPlans: PricingPlan[] = [
  {
    id: 'p1',
    name: 'Starter',
    price: 'Free',
    description: 'Launch quickly with essential analytics and unlimited reports.',
    features: ['Unlimited dashboards', 'Starter automation', 'Community support'],
    isHighlighted: false,
  },
  {
    id: 'p2',
    name: 'Professional',
    price: '$29/month',
    description: 'Scale engagement with advanced workflows and AI insights.',
    features: ['Everything in Starter', 'AI recommendations', 'Priority support', 'Custom alerts'],
    isHighlighted: true,
  },
  {
    id: 'p3',
    name: 'Enterprise',
    price: 'Custom',
    description: 'Tailored security, compliance, and dedicated success teams.',
    features: ['Dedicated CSM', 'SSO + compliance', 'Private onboarding'],
    isHighlighted: false,
  },
];

export const resources: ResourceItem[] = [
  {
    id: 'r1',
    title: 'Engagement Playbooks',
    description: 'Battle-tested templates for lifecycle campaigns and product launches.',
  },
  {
    id: 'r2',
    title: 'ROI Calculator',
    description: 'Estimate revenue impact with automation and customer insights.',
  },
  {
    id: 'r3',
    title: 'Security Center',
    description: 'Compliance notes, encryption standards, and audit readiness.',
  },
];

export const companyValues: CompanyValue[] = [
  {
    id: 'cv1',
    title: 'Trust by Design',
    description: 'Built with secure infrastructure and privacy-first practices.',
  },
  {
    id: 'cv2',
    title: 'Speed at Scale',
    description: 'Fast decisions with real-time analytics and proactive insights.',
  },
  {
    id: 'cv3',
    title: 'Human Support',
    description: 'Premium customer success teams and rapid response SLAs.',
  },
];
