export const colors = {
  primary: '#4DA3FF',
  primaryDark: '#2F86E5',
  primaryLight: '#D7ECFF',
  accent: '#7BC3FF',
  background: '#EAF4FF',
  surface: '#F5FAFF',
  card: '#F7FBFF',
  border: '#D6E6F5',
  textPrimary: '#18324F',
  textSecondary: '#5B738F',
  textDisabled: '#9BB0C4',
  textInverse: '#FFFFFF',
  success: '#5FB8FF',
  warning: '#8FD3FF',
  error: '#E96A6A',
  info: '#4DA3FF',
  shadowColor: '#000000',
} as const;

export type Colors = typeof colors;
