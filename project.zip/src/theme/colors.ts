export const colors = {
  primary: '#3B82F6',
  primaryDark: '#1D4ED8',
  primaryLight: '#DBEAFE',
  accent: '#A855F7',
  background: '#F5F7FB',
  surface: '#FFFFFF',
  card: '#FFFFFF',
  border: '#E5E7EB',
  textPrimary: '#0F172A',
  textSecondary: '#475569',
  textDisabled: '#94A3B8',
  textInverse: '#FFFFFF',
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#0EA5E9',
  shadowColor: '#000000',
} as const;

export type Colors = typeof colors;
