const { withDangerousMod, withXcodeProject } = require("@expo/config-plugins");
const fs = require("fs");
const path = require("path");

// Two-pronged fix for Xcode 26 RC "module map file not found":
//
// Root cause: Xcode 26 enables CLANG_ENABLE_EXPLICIT_MODULES by default.
// Expo pod targets must emit .modulemap files for the AppRN Swift bridging
// header precompilation to succeed. When explicit modules is ON but the maps
// can't be found (or when it's OFF but the main target still expects them),
// the archive fails.
//
// Fix: (a) Inject into the last hook block of the Podfile (post_install or
// post_integrate, whichever appears last) so our settings run after
// react_native_post_install and cannot be overridden.  (b) Use withXcodeProject
// to bake the setting into AppRN.xcodeproj so it's on disk before xcodebuild
// ever runs, eliminating any reliance on xcargs alone.

module.exports = function withExplicitModules(config) {
  // ── Patch 1: Podfile — inject into the last hook block ──
  // We inject into the LAST hook block (post_install or post_integrate) that
  // already exists in the Podfile rather than appending a new post_integrate.
  // CocoaPods rejects duplicate post_integrate hooks with "Specifying multiple
  // `post_integrate` hooks is unsupported." — Expo and its native module
  // packages already add one, so we must never create a second.
  //
  // Strategy: find the last standalone `end` line (the closing of the outermost
  // hook block) and insert our settings immediately before it. This is more
  // robust than Ruby block-depth counting, which breaks on nested do/end
  // constructs inside comments, strings, or complex hook bodies.
  config = withDangerousMod(config, [
    "ios",
    (modConfig) => {
      const podfilePath = path.join(
        modConfig.modRequest.platformProjectRoot,
        "Podfile"
      );
      if (!fs.existsSync(podfilePath)) return modConfig;

      let podfile = fs.readFileSync(podfilePath, "utf8");
      const marker = "# [withExplicitModules] already applied";
      if (podfile.includes(marker)) return modConfig;

      // Set on every pod target (target-level) AND on the Pods project itself
      // (project-level) so there is no inheritance path back to YES.
      const settingsLines = [
        "  # [withExplicitModules] disable explicit modules for Xcode 26+",
        "  # Injected after react_native_post_install so it cannot be overridden.",
        "  installer.pods_project.targets.each do |target|",
        "    target.build_configurations.each do |bcfg|",
        '      bcfg.build_settings["CLANG_ENABLE_EXPLICIT_MODULES"] = "NO"',
        '      bcfg.build_settings["SWIFT_ENABLE_EXPLICIT_MODULES"] = "NO"',
        "    end",
        "  end",
        "  installer.pods_project.build_configurations.each do |bcfg|",
        '    bcfg.build_settings["CLANG_ENABLE_EXPLICIT_MODULES"] = "NO"',
        '    bcfg.build_settings["SWIFT_ENABLE_EXPLICIT_MODULES"] = "NO"',
        "  end",
        `  # ${marker}`,
      ].join("\n");

      // Walk backwards to find the last standalone `end` line — the closing
      // of the outermost hook block (post_install or post_integrate).
      const lines = podfile.split("\n");
      let lastEndIdx = -1;
      for (let i = lines.length - 1; i >= 0; i--) {
        if (/^\s*end\s*$/.test(lines[i])) {
          lastEndIdx = i;
          break;
        }
      }

      const hasHookBlock = podfile.includes("post_install") || podfile.includes("post_integrate");
      if (lastEndIdx >= 0 && hasHookBlock) {
        lines.splice(lastEndIdx, 0, settingsLines);
        podfile = lines.join("\n");
      } else {
        // No existing hook block found — append a post_install block.
        podfile = podfile.trimEnd() + "\n\npost_install do |installer|\n" + settingsLines + "\nend\n";
      }
      fs.writeFileSync(podfilePath, podfile);
      return modConfig;
    },
  ]);

  // ── Patch 2: AppRN.xcodeproj — bake the setting into the project file ──
  // withXcodeProject runs during expo prebuild and writes project.pbxproj to
  // disk before pod install or xcodebuild ever runs.  Setting it here in the
  // main app project ensures the PrecompileSwiftBridgingHeader phase (which
  // reads project file settings, not just xcargs) sees NO on the AppRN target.
  config = withXcodeProject(config, (modConfig) => {
    const xcodeProject = modConfig.modResults;
    const configurations = xcodeProject.pbxXCBuildConfigurationSection();
    for (const [, buildConfig] of Object.entries(configurations)) {
      if (typeof buildConfig === "string") continue;
      if (!buildConfig.buildSettings) continue;
      buildConfig.buildSettings.CLANG_ENABLE_EXPLICIT_MODULES = "NO";
      buildConfig.buildSettings.SWIFT_ENABLE_EXPLICIT_MODULES = "NO";
    }
    return modConfig;
  });

  return config;
};
