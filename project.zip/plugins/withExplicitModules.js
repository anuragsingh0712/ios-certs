const { withDangerousMod } = require("@expo/config-plugins");
const fs = require("fs");
const path = require("path");

// Inject CLANG_ENABLE_EXPLICIT_MODULES=NO into the EXISTING post_install block.
// CocoaPods forbids multiple post_install hooks — appending a second one causes
// "Specifying multiple post_install hooks is unsupported" and aborts pod install.
// Xcode 26+ enables explicit modules by default, which prevents Expo SDK pods
// from emitting their .modulemap files → Swift compile fails with
// "module map file … not found".
module.exports = function withExplicitModules(config) {
  return withDangerousMod(config, [
    "ios",
    (modConfig) => {
      const podfilePath = path.join(
        modConfig.modRequest.platformProjectRoot,
        "Podfile"
      );
      if (!fs.existsSync(podfilePath)) return modConfig;

      let podfile = fs.readFileSync(podfilePath, "utf8");
      const marker = "# [withExplicitModules] already applied";
      if (podfile.includes(marker)) return modConfig;

      // Snippet to inject — uses `bcfg` to avoid shadowing JS variables.
      const snippet = [
        "  # [withExplicitModules] disable explicit modules for Xcode 26+",
        "  installer.pods_project.targets.each do |target|",
        "    target.build_configurations.each do |bcfg|",
        '      bcfg.build_settings["CLANG_ENABLE_EXPLICIT_MODULES"] = "NO"',
        '      bcfg.build_settings["SWIFT_ENABLE_EXPLICIT_MODULES"] = "NO"',
        "    end",
        "  end",
        `  ${marker}`,
      ].join("\n");

      if (podfile.includes("post_install do |installer|")) {
        // Insert snippet right after the opening line of the existing block.
        podfile = podfile.replace(
          "post_install do |installer|",
          "post_install do |installer|\n" + snippet
        );
      } else {
        // No post_install at all — add one (safe, single occurrence).
        podfile += "\npost_install do |installer|\n" + snippet + "\nend\n";
      }

      fs.writeFileSync(podfilePath, podfile);
      return modConfig;
    },
  ]);
};
