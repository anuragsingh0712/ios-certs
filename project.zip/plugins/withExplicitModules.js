const { withDangerousMod } = require("@expo/config-plugins");
const fs = require("fs");
const path = require("path");

// Patch the Podfile post_install block to disable explicit modules on all pod
// targets.  Xcode 26+ enables CLANG_ENABLE_EXPLICIT_MODULES by default, which
// prevents Expo SDK pods from emitting their .modulemap files and causes Swift
// compilation to fail with "module map file … not found".
module.exports = function withExplicitModules(config) {
  return withDangerousMod(config, [
    "ios",
    (config) => {
      const podfilePath = path.join(
        config.modRequest.platformProjectRoot,
        "Podfile"
      );
      if (!fs.existsSync(podfilePath)) return config;

      let podfile = fs.readFileSync(podfilePath, "utf8");
      const marker = "# [withExplicitModules] already applied";
      if (podfile.includes(marker)) return config;

      const patch = `\npost_install do |installer|\n  installer.pods_project.targets.each do |target|\n    target.build_configurations.each do |config|\n      config.build_settings["CLANG_ENABLE_EXPLICIT_MODULES"] = "NO"\n      config.build_settings["SWIFT_ENABLE_EXPLICIT_MODULES"] = "NO"\n    end\n  end\nend\n# ${marker}\n`;
      fs.appendFileSync(podfilePath, patch);
      return config;
    },
  ]);
};
